import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';

const browserDistFolder = join(import.meta.dirname, '../browser');
const dataDir = join(process.cwd(), 'data');

if (!existsSync(dataDir)) {
  try {
    mkdirSync(dataDir, { recursive: true });
  } catch (err) {
    console.warn('Could not create data dir:', err);
  }
}

const productsFilePath = join(dataDir, 'products.json');
const settingsFilePath = join(dataDir, 'settings.json');
const ordersFilePath = join(dataDir, 'orders.json');

const app = express();
const angularApp = new AngularNodeAppEngine();

// Support high-resolution image uploads in JSON payload (up to 50MB)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Default store settings
const DEFAULT_SETTINGS = {
  countryCode: '+91',
  whatsappPhone: '9876543210',
  contactEmail: 'concierge@godsprints.in',
  instagram: '@godsprints',
  storeLocation: 'India Studio · Online Direct-to-Consumer',
  brandBio: 'GODS PRINTS is an independent anime streetwear atelier crafting ultra-heavyweight Japanese street cuts, occult anime iconography, and artisan mineral acid washes. 100% combed cotton, zero compromises.',
  paymentNotice: 'PREPAID ORDERS ONLY · NO CASH ON DELIVERY',
  paymentUpiId: 'godsprints@upi',
  paymentInstructions: 'All orders are processed and queued for dispatch immediately upon receipt of payment confirmation. Once you submit your order, share the confirmation on WhatsApp to receive the payment QR / UPI handle.',
  returnHours: 24,
  returnPolicyText: 'Return requests must be initiated within 24 hours of package delivery via our WhatsApp line. Due to our limited drop production, returns are accepted exclusively for transit damage or verified sizing mismatch with original product tags and unboxing photos. Claims are evaluated within 24 hours.',
  adminPin: 'gods2026',
};

// Helper file functions
function readJsonFile<T>(filePath: string, fallback: T): T {
  try {
    if (existsSync(filePath)) {
      const data = readFileSync(filePath, 'utf-8');
      return JSON.parse(data) as T;
    }
  } catch (e) {
    console.warn(`Error reading ${filePath}:`, e);
  }
  return fallback;
}

function writeJsonFile<T>(filePath: string, data: T): boolean {
  try {
    writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (e) {
    console.warn(`Error writing ${filePath}:`, e);
    return false;
  }
}

// ==========================================
// REST API ENDPOINTS
// ==========================================

// 1. GET Products
app.get('/api/products', (_req, res) => {
  const products = readJsonFile(productsFilePath, null);
  res.json({ success: true, products });
});

// 2. POST Products (Save / Update All)
app.post('/api/products', (req, res) => {
  const { products } = req.body;
  if (!Array.isArray(products)) {
    res.status(400).json({ success: false, error: 'Invalid products array' });
    return;
  }
  const ok = writeJsonFile(productsFilePath, products);
  res.json({ success: ok, count: products.length });
});

// 3. GET Settings
app.get('/api/settings', (_req, res) => {
  const settings = readJsonFile(settingsFilePath, DEFAULT_SETTINGS);
  // Do not expose admin PIN in public settings
  const safeSettings = { ...(settings as typeof DEFAULT_SETTINGS) };
  delete (safeSettings as { adminPin?: string }).adminPin;
  res.json({ success: true, settings: safeSettings });
});

// 4. POST Settings (Update Settings)
app.post('/api/settings', (req, res) => {
  const updates = req.body;
  const current = readJsonFile(settingsFilePath, DEFAULT_SETTINGS);
  const updated = { ...current, ...updates };
  const ok = writeJsonFile(settingsFilePath, updated);
  const safeSettings = { ...updated };
  delete (safeSettings as { adminPin?: string }).adminPin;
  res.json({ success: ok, settings: safeSettings });
});

// 5. Admin Authentication Verification
app.post('/api/admin/verify', (req, res) => {
  const { pin } = req.body;
  const current = readJsonFile(settingsFilePath, DEFAULT_SETTINGS);
  const expectedPin = current.adminPin || 'gods2026';
  if (pin === expectedPin) {
    res.json({ success: true, authenticated: true });
  } else {
    res.status(401).json({ success: false, authenticated: false, message: 'Invalid admin credentials' });
  }
});

// 6. POST Orders (Log order request server-side)
app.post('/api/orders', (req, res) => {
  const order = req.body;
  const orders = readJsonFile<Record<string, unknown>[]>(ordersFilePath, []);
  const newOrder = {
    ...order,
    id: order.id || `GP-${Date.now().toString().slice(-5)}`,
    createdAt: new Date().toISOString(),
    status: 'Awaiting Payment Confirmation',
  };
  orders.unshift(newOrder);
  writeJsonFile(ordersFilePath, orders.slice(0, 200)); // retain latest 200 orders
  res.json({ success: true, orderId: newOrder.id });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
