import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-zoom-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  host: {
    '(window:keydown)': 'handleKeyDown($event)',
    '(window:mouseup)': 'stopDrag()',
    '(window:touchend)': 'stopDrag()',
  },
  template: `
    @if (store.isZoomOpen()) {
      <div class="fixed inset-0 z-50 flex flex-col bg-black/95 backdrop-blur-xl select-none overflow-hidden">
        
        <!-- ============================================== -->
        <!-- TOP TOOLBAR: METADATA & CONTROL BUTTONS       -->
        <!-- ============================================== -->
        <div class="flex items-center justify-between px-4 sm:px-8 py-3.5 border-b border-white/10 bg-[#07070a]/90 backdrop-blur-md z-30 shrink-0">
          
          <!-- Left: Product Identity & Native Resolution Pill -->
          <div class="flex items-center gap-3 sm:gap-4 min-w-0">
            <div class="min-w-0">
              <div class="flex items-center gap-2">
                <span class="font-display font-bold text-white text-sm sm:text-base uppercase tracking-wider truncate">
                  {{ store.activeProduct().name }}
                </span>
                <span class="text-xs font-mono text-red-500 font-bold uppercase tracking-wider shrink-0">
                  {{ store.activeGalleryView() === 'front' ? 'FRONT VIEW' : 'BACK VIEW' }}
                </span>
              </div>
              <div class="flex items-center gap-2 text-[11px] font-mono text-neutral-400 mt-0.5">
                @if (naturalResolution()) {
                  <span class="text-emerald-400 font-semibold">
                    {{ naturalResolution() }}
                  </span>
                  <span>·</span>
                }
                <span class="text-neutral-500">
                  {{ currentZoomPercent() }} Zoom
                </span>
              </div>
            </div>
          </div>

          <!-- Right: Interactive Controls -->
          <div class="flex items-center gap-2 sm:gap-3">
            
            <!-- Quick Zoom Toggles -->
            <div class="hidden md:flex items-center bg-neutral-900/90 border border-neutral-800 rounded-xl p-1 gap-1">
              <button
                type="button"
                (click)="setZoomFit()"
                [class]="zoomScale() === 1 ? 'bg-red-600 text-white font-bold' : 'text-neutral-300 hover:text-white'"
                class="px-2.5 py-1 rounded-lg text-xs font-mono transition-colors"
                title="Fit to screen (Key: 0)"
              >
                Fit
              </button>
              <button
                type="button"
                (click)="setZoom100()"
                [class]="zoomScale() === 1.8 ? 'bg-red-600 text-white font-bold' : 'text-neutral-300 hover:text-white'"
                class="px-2.5 py-1 rounded-lg text-xs font-mono transition-colors"
                title="100% Original Resolution (Key: 1)"
              >
                100% Original
              </button>
              <button
                type="button"
                (click)="setZoom(2.8)"
                [class]="zoomScale() === 2.8 ? 'bg-red-600 text-white font-bold' : 'text-neutral-300 hover:text-white'"
                class="px-2.5 py-1 rounded-lg text-xs font-mono transition-colors"
                title="Deep Detail Zoom (Key: 2)"
              >
                200% Detail
              </button>
            </div>

            <!-- Zoom In / Out Buttons -->
            <div class="flex items-center bg-neutral-900 border border-neutral-800 rounded-xl overflow-hidden">
              <button
                type="button"
                (click)="zoomOut()"
                class="w-9 h-9 flex items-center justify-center text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors"
                title="Zoom Out (Key: -)"
                aria-label="Zoom out"
              >
                <mat-icon class="text-base">remove</mat-icon>
              </button>
              <span class="px-2 font-mono text-xs text-neutral-400 font-semibold tabular-nums min-w-[3.5rem] text-center">
                {{ currentZoomPercent() }}
              </span>
              <button
                type="button"
                (click)="zoomIn()"
                class="w-9 h-9 flex items-center justify-center text-neutral-300 hover:text-white hover:bg-neutral-800 transition-colors"
                title="Zoom In (Key: +)"
                aria-label="Zoom in"
              >
                <mat-icon class="text-base">add</mat-icon>
              </button>
            </div>

            <!-- Toggle Front / Back View -->
            <button
              type="button"
              (click)="toggleView()"
              class="px-3 sm:px-4 py-2 rounded-xl bg-neutral-900 border border-neutral-700 hover:border-white text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-colors"
              title="Toggle Front / Back view (Key: F or B)"
            >
              <mat-icon class="text-base">flip</mat-icon>
              <span class="hidden sm:inline">Switch to {{ store.activeGalleryView() === 'front' ? 'Back' : 'Front' }}</span>
              <span class="sm:hidden">{{ store.activeGalleryView() === 'front' ? 'Back' : 'Front' }}</span>
            </button>

            <!-- Reset Button -->
            @if (zoomScale() !== 1 || panX() !== 0 || panY() !== 0) {
              <button
                type="button"
                (click)="resetView()"
                class="w-9 h-9 rounded-xl bg-neutral-900 border border-neutral-800 hover:border-neutral-600 text-neutral-300 hover:text-white flex items-center justify-center transition-colors"
                title="Reset zoom and pan"
                aria-label="Reset zoom and position"
              >
                <mat-icon class="text-base">restart_alt</mat-icon>
              </button>
            }

            <!-- Close Button -->
            <button
              type="button"
              (click)="closeZoom()"
              class="w-9 h-9 rounded-xl bg-red-600/90 hover:bg-red-600 text-white flex items-center justify-center transition-colors shadow-lg shadow-red-600/20"
              title="Close Zoom (Esc)"
              aria-label="Close zoom"
            >
              <mat-icon class="text-lg">close</mat-icon>
            </button>
          </div>
        </div>

        <!-- ============================================== -->
        <!-- CENTER VIEWPORT: HIGH-RESOLUTION ZOOM CANVAS   -->
        <!-- ============================================== -->
        <div
          class="flex-1 relative overflow-hidden flex items-center justify-center p-4 cursor-default"
          (wheel)="handleWheel($event)"
          (mousedown)="startDrag($event)"
          (mousemove)="onDrag($event)"
          (touchstart)="startTouch($event)"
          (touchmove)="onTouch($event)"
          [class.cursor-grab]="zoomScale() > 1 && !isDragging()"
          [class.cursor-grabbing]="isDragging()"
        >
          <!-- Background Grid Guide -->
          <div class="absolute inset-0 bg-[radial-gradient(#1f1f26_1px,transparent_1px)] [background-size:24px_24px] opacity-25 pointer-events-none"></div>

          <!-- Scaled Image Container -->
          <div
            class="relative max-w-full max-h-full flex items-center justify-center transition-transform duration-75 ease-out"
            [style.transform]="transformStyle()"
          >
            <img
              [src]="currentImage()"
              [alt]="store.activeProduct().name + ' High Resolution Original'"
              class="max-w-[85vw] max-h-[75vh] object-contain select-none shadow-2xl rounded-2xl pointer-events-none img-sharp"
              referrerpolicy="no-referrer"
              (load)="onImageLoad($event)"
              (dblclick)="handleDoubleClick()"
            />
          </div>

          <!-- On-Canvas Zoom & Pan Guidance Overlay (fades out when interacting) -->
          <div class="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs font-mono text-neutral-400 pointer-events-none z-20">
            <div class="bg-black/75 px-3 py-1.5 rounded-lg border border-white/10 backdrop-blur-md">
              <span>Scroll wheel or pinch to zoom · Drag to pan across details · Double-click to toggle zoom</span>
            </div>
            <div class="hidden sm:block bg-black/75 px-3 py-1.5 rounded-lg border border-white/10 backdrop-blur-md text-emerald-400 font-semibold">
              <span>100% Uncompressed Original Resolution</span>
            </div>
          </div>
        </div>

      </div>
    }
  `,
})
export class ZoomModalComponent {
  readonly store = inject(StoreService);

  // Zoom and Pan states
  readonly zoomScale = signal<number>(1);
  readonly panX = signal<number>(0);
  readonly panY = signal<number>(0);
  readonly isDragging = signal<boolean>(false);
  
  // Natural image dimensions
  readonly naturalWidth = signal<number>(0);
  readonly naturalHeight = signal<number>(0);

  // Drag coordinates tracking
  private startMouseX = 0;
  private startMouseY = 0;
  private initialPanX = 0;
  private initialPanY = 0;

  readonly currentImage = computed(() => {
    const p = this.store.activeProduct();
    return this.store.activeGalleryView() === 'front' ? p.frontImage : p.backImage;
  });

  readonly naturalResolution = computed<string | null>(() => {
    const w = this.naturalWidth();
    const h = this.naturalHeight();
    if (w > 0 && h > 0) {
      return `${w} × ${h} px Original`;
    }
    return null;
  });

  readonly currentZoomPercent = computed<string>(() => {
    const scale = this.zoomScale();
    return `${Math.round(scale * 100)}%`;
  });

  readonly transformStyle = computed<string>(() => {
    const scale = this.zoomScale();
    const x = this.panX();
    const y = this.panY();
    return `translate3d(${x}px, ${y}px, 0) scale(${scale})`;
  });

  onImageLoad(event: Event) {
    const img = event.target as HTMLImageElement;
    if (img) {
      this.naturalWidth.set(img.naturalWidth || img.width);
      this.naturalHeight.set(img.naturalHeight || img.height);
    }
  }

  setZoomFit() {
    this.zoomScale.set(1);
    this.panX.set(0);
    this.panY.set(0);
  }

  setZoom100() {
    this.zoomScale.set(1.8);
    this.panX.set(0);
    this.panY.set(0);
  }

  setZoom(level: number) {
    this.zoomScale.set(level);
  }

  zoomIn() {
    const current = this.zoomScale();
    const next = Math.min(4.5, Number((current + 0.35).toFixed(2)));
    this.zoomScale.set(next);
  }

  zoomOut() {
    const current = this.zoomScale();
    const next = Math.max(1, Number((current - 0.35).toFixed(2)));
    this.zoomScale.set(next);
    if (next === 1) {
      this.panX.set(0);
      this.panY.set(0);
    }
  }

  resetView() {
    this.zoomScale.set(1);
    this.panX.set(0);
    this.panY.set(0);
  }

  toggleView() {
    this.store.setGalleryView(this.store.activeGalleryView() === 'front' ? 'back' : 'front');
  }

  closeZoom() {
    this.resetView();
    this.store.closeZoom();
  }

  handleWheel(event: WheelEvent) {
    event.preventDefault();
    if (event.deltaY < 0) {
      this.zoomIn();
    } else {
      this.zoomOut();
    }
  }

  handleDoubleClick() {
    if (this.zoomScale() > 1) {
      this.resetView();
    } else {
      this.setZoom100();
    }
  }

  startDrag(event: MouseEvent) {
    if (this.zoomScale() <= 1) return;
    this.isDragging.set(true);
    this.startMouseX = event.clientX;
    this.startMouseY = event.clientY;
    this.initialPanX = this.panX();
    this.initialPanY = this.panY();
  }

  onDrag(event: MouseEvent) {
    if (!this.isDragging() || this.zoomScale() <= 1) return;
    const dx = event.clientX - this.startMouseX;
    const dy = event.clientY - this.startMouseY;
    this.panX.set(this.initialPanX + dx);
    this.panY.set(this.initialPanY + dy);
  }

  startTouch(event: TouchEvent) {
    if (this.zoomScale() <= 1 || event.touches.length === 0) return;
    this.isDragging.set(true);
    this.startMouseX = event.touches[0].clientX;
    this.startMouseY = event.touches[0].clientY;
    this.initialPanX = this.panX();
    this.initialPanY = this.panY();
  }

  onTouch(event: TouchEvent) {
    if (!this.isDragging() || this.zoomScale() <= 1 || event.touches.length === 0) return;
    const dx = event.touches[0].clientX - this.startMouseX;
    const dy = event.touches[0].clientY - this.startMouseY;
    this.panX.set(this.initialPanX + dx);
    this.panY.set(this.initialPanY + dy);
  }

  stopDrag() {
    this.isDragging.set(false);
  }

  handleKeyDown(event: KeyboardEvent) {
    if (!this.store.isZoomOpen()) return;

    if (event.key === 'Escape') {
      this.closeZoom();
    } else if (event.key === '+' || event.key === '=') {
      this.zoomIn();
    } else if (event.key === '-' || event.key === '_') {
      this.zoomOut();
    } else if (event.key === '0') {
      this.setZoomFit();
    } else if (event.key === '1') {
      this.setZoom100();
    } else if (event.key === 'f' || event.key === 'F' || event.key === 'b' || event.key === 'B') {
      this.toggleView();
    }
  }
}
