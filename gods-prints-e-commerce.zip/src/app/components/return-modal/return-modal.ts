import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';
import { ReturnRequest } from '../../models/product.model';
import { generateWhatsAppReturnUrl } from '../../utils/store-logic';

@Component({
  selector: 'app-return-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.isReturnModalOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4">
        <!-- Backdrop -->
        <div
          class="fixed inset-0 bg-black/85 backdrop-blur-md"
          (click)="store.closeReturnModal()"
          (keydown.escape)="store.closeReturnModal()"
          tabindex="0"
          role="button"
          aria-label="Close modal overlay"
        ></div>

        <div class="relative w-full max-w-lg max-h-[90vh] flex flex-col bg-[#0d0d12] border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-10">
          
          <!-- Header (Always visible) -->
          <div class="px-6 py-4 bg-[#121219] border-b border-white/10 flex items-center justify-between shrink-0">
            <div class="flex items-center gap-2">
              <mat-icon class="text-red-500">assignment_return</mat-icon>
              <h3 class="font-display text-base font-bold text-white uppercase tracking-wider">
                24-HOUR RETURN &amp; EXCHANGE REQUEST
              </h3>
            </div>
            <button
              type="button"
              (click)="store.closeReturnModal()"
              class="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center cursor-pointer"
              aria-label="Close return dialog"
            >
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>

          <div class="p-6 space-y-5 overflow-y-auto flex-1">
            
            <!-- Policy Warning / Transparency Pill -->
            <div class="p-4 rounded-xl bg-red-950/20 border border-red-500/30 text-xs font-mono space-y-1.5">
              <div class="flex items-center gap-1.5 text-red-400 font-bold uppercase tracking-wider">
                <mat-icon class="text-sm">info</mat-icon>
                <span>24-Hour Policy Window</span>
              </div>
              <p class="text-neutral-300 leading-relaxed">
                {{ store.settings().returnPolicyText }}
              </p>
            </div>

            @if (returnUrl()) {
              <!-- Ready to forward state -->
              <div class="text-center space-y-4 py-3">
                <div class="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <mat-icon class="text-2xl">chat</mat-icon>
                </div>
                <div class="space-y-1">
                  <h4 class="font-display text-lg font-bold text-white uppercase">Ready to Submit via WhatsApp</h4>
                  <p class="text-xs font-mono text-neutral-400 max-w-sm mx-auto">
                    Your claim ticket has been generated. Tap below to send details directly to the styling desk and attach photos of the defect.
                  </p>
                </div>

                <div class="space-y-2 pt-2">
                  <a
                    [href]="returnUrl()"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="w-full h-12 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20"
                  >
                    <span>SUBMIT RETURN ON WHATSAPP</span>
                    <mat-icon class="text-sm">arrow_forward</mat-icon>
                  </a>

                  <button
                    type="button"
                    (click)="returnUrl.set(null)"
                    class="w-full h-10 rounded-xl bg-neutral-900 text-neutral-400 hover:text-white text-xs font-mono uppercase transition-colors"
                  >
                    Edit Claim Details
                  </button>
                </div>
              </div>

            } @else {
              <!-- Return Form -->
              <form [formGroup]="returnForm" (ngSubmit)="submitReturn()" class="space-y-4">
                
                <!-- Order ID -->
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Order Reference ID *</span>
                  <input
                    type="text"
                    formControlName="orderId"
                    placeholder="e.g. GP-84920"
                    class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                  />
                  <span class="text-[10px] text-neutral-500 font-mono">Found on your order confirmation receipt</span>
                </div>

                <!-- Customer Name & Phone -->
                <div class="grid grid-cols-2 gap-3">
                  <div class="space-y-1">
                    <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Your Name *</span>
                    <input
                      type="text"
                      formControlName="customerName"
                      placeholder="e.g. Ishaan"
                      class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                    />
                  </div>
                  <div class="space-y-1">
                    <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Contact Phone *</span>
                    <input
                      type="tel"
                      formControlName="phone"
                      placeholder="e.g. 9876543210"
                      class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                    />
                  </div>
                </div>

                <!-- Reason Selector -->
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Primary Reason *</span>
                  <select
                    formControlName="reason"
                    class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                  >
                    <option value="transit_damage">Transit Damage / Damaged Outer Packaging</option>
                    <option value="sizing_mismatch">Verified Sizing Mismatch (Unworn with Tags)</option>
                    <option value="wrong_item">Incorrect Product or Color Received</option>
                    <option value="other">Print or Stitching Defect</option>
                  </select>
                </div>

                <!-- Explanation Description -->
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Description of Issue *</span>
                  <textarea
                    rows="3"
                    formControlName="description"
                    placeholder="Describe what is wrong with the product. You will be prompted to attach unboxing photos on WhatsApp..."
                    class="w-full p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono leading-relaxed focus:border-red-500 focus:outline-none resize-none"
                  ></textarea>
                </div>

                <!-- Photo Prompt Notice -->
                <div class="p-3 rounded-lg bg-[#14141c] border border-white/5 text-[11px] font-mono text-neutral-400 flex items-center gap-2">
                  <mat-icon class="text-sm text-yellow-500">photo_camera</mat-icon>
                  <span>Product tags must be intact. Have your unboxing photos ready.</span>
                </div>

                <div class="pt-2">
                  <button
                    type="submit"
                    [disabled]="returnForm.invalid"
                    class="w-full h-12 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-mono text-xs font-bold uppercase tracking-wider transition-all shadow-xl shadow-red-600/20 flex items-center justify-center gap-2"
                  >
                    <mat-icon class="text-base">assignment_return</mat-icon>
                    <span>PROCEED WITH RETURN REQUEST</span>
                  </button>
                </div>

              </form>
            }

          </div>

        </div>
      </div>
    }
  `,
})
export class ReturnModalComponent {
  readonly store = inject(StoreService);
  private readonly fb = inject(FormBuilder);

  readonly returnUrl = signal<string | null>(null);

  readonly returnForm = this.fb.group({
    orderId: ['', [Validators.required, Validators.minLength(4)]],
    customerName: ['', Validators.required],
    phone: ['', [Validators.required, Validators.minLength(10)]],
    reason: ['transit_damage' as 'transit_damage' | 'sizing_mismatch' | 'wrong_item' | 'other', Validators.required],
    description: ['', [Validators.required, Validators.minLength(10)]],
  });

  submitReturn() {
    if (this.returnForm.invalid) return;

    const val = this.returnForm.value;
    const reasonMap: Record<string, string> = {
      transit_damage: 'Transit Damage / Torn Packaging',
      sizing_mismatch: 'Verified Sizing Mismatch',
      wrong_item: 'Incorrect Item Received',
      other: 'Defect / Stitching Flaw',
    };

    const req: ReturnRequest = {
      orderId: (val.orderId || '').replace('#', '').trim(),
      customerName: val.customerName || '',
      phone: val.phone || '',
      reason: val.reason || 'transit_damage',
      reasonText: reasonMap[val.reason || 'transit_damage'] || 'Item Issue',
      description: val.description || '',
    };

    const url = generateWhatsAppReturnUrl(this.store.fullWhatsAppNumber(), req);
    this.returnUrl.set(url);
  }
}
