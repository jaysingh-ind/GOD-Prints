import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-about',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <section id="about" class="py-24 bg-[#08080b] border-b border-white/5 scroll-mt-20 relative overflow-hidden">
      <!-- Ambient light effect -->
      <div class="absolute -top-32 right-1/4 w-96 h-96 bg-red-600/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Section Header -->
        <div class="max-w-3xl mb-16 space-y-4">
          <div class="text-xs font-mono uppercase tracking-widest text-red-500 flex items-center gap-2">
            <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
            PHILOSOPHY // 神々の力 · GENUINE ATELIER
          </div>
          <h2 class="font-display text-3xl sm:text-5xl font-black uppercase text-white tracking-tight leading-tight">
            WHERE LEGENDARY ANIME FOLKLORE MEETS LUXURY STREETWEAR.
          </h2>
          <p class="text-sm sm:text-base text-neutral-300 leading-relaxed font-light">
            {{ store.settings().brandBio }}
          </p>
          <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-neutral-900 border border-white/10 text-xs font-mono text-neutral-400">
            <mat-icon class="text-xs text-red-500">storefront</mat-icon>
            <span>{{ store.settings().storeLocation }}</span>
          </div>
        </div>

        <!-- 3 Pillars Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          <!-- Pillar 1 -->
          <div class="p-8 rounded-2xl bg-[#0e0e13] border border-white/10 space-y-4 hover:border-red-500/30 transition-all group">
            <div class="w-12 h-12 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-red-500 group-hover:scale-110 transition-transform">
              <mat-icon class="text-2xl">layers</mat-icon>
            </div>
            <div class="text-xs font-mono text-neutral-500">01. HEAVYWEIGHT FOUNDATION</div>
            <h3 class="font-display text-xl font-bold text-white uppercase">420 GSM French Terry</h3>
            <p class="text-xs text-neutral-400 leading-relaxed">
              We exclusively source combed 100% long-staple cotton loopback terry. The 420 GSM weight creates the iconic architectural drop-shoulder silhouette that sits structured on your frame without collapsing.
            </p>
          </div>

          <!-- Pillar 2 -->
          <div class="p-8 rounded-2xl bg-[#0e0e13] border border-white/10 space-y-4 hover:border-red-500/30 transition-all group">
            <div class="w-12 h-12 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-red-500 group-hover:scale-110 transition-transform">
              <mat-icon class="text-2xl">water_drop</mat-icon>
            </div>
            <div class="text-xs font-mono text-neutral-500">02. BESPOKE DISTRESSING</div>
            <h3 class="font-display text-xl font-bold text-white uppercase">Artisan Mineral Acid Wash</h3>
            <p class="text-xs text-neutral-400 leading-relaxed">
              No two garments are identical. Each piece is submerged in our specialized mineral acid tumbling process to forge a tactile, smoky vintage charcoal patina inspired by underground brutalist architecture.
            </p>
          </div>

          <!-- Pillar 3 -->
          <div class="p-8 rounded-2xl bg-[#0e0e13] border border-white/10 space-y-4 hover:border-red-500/30 transition-all group">
            <div class="w-12 h-12 rounded-xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-red-500 group-hover:scale-110 transition-transform">
              <mat-icon class="text-2xl">texture</mat-icon>
            </div>
            <div class="text-xs font-mono text-neutral-500">03. TACTILE IMPRINT</div>
            <h3 class="font-display text-xl font-bold text-white uppercase">High-Density 3D Puff Print</h3>
            <p class="text-xs text-neutral-400 leading-relaxed">
              Our iconic Shadow Eye graphics combine microscopic razor-sharp screen ink with raised high-density puff embossing, creating a dimensional tactile relief that will not crack or peel through dozens of wash cycles.
            </p>
          </div>

        </div>

      </div>
    </section>
  `,
})
export class AboutComponent {
  readonly store = inject(StoreService);
}
