import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-footer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <footer class="bg-[#050507] border-t border-white/5 py-16 text-neutral-400">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        <div class="flex flex-col md:flex-row md:items-start justify-between gap-10">
          <!-- Brand & Tagline -->
          <div class="space-y-4 max-w-sm">
            <div class="flex items-center gap-2">
              <div class="w-2.5 h-2.5 rounded-full bg-red-600"></div>
              <span class="font-display text-2xl font-black tracking-wider text-white uppercase">
                GODS PRINTS
              </span>
              <span class="text-[10px] font-mono text-neutral-500 uppercase border-l border-neutral-800 pl-2">
                神の印
              </span>
            </div>

            <p class="text-xs text-neutral-400 leading-relaxed font-mono">
              Premium anime streetwear crafted with 420 GSM French Terry cotton and bespoke Japanese mineral acid wash. Wear Your Power.
            </p>

            <div class="space-y-1 text-[11px] font-mono text-neutral-500">
              <div class="flex items-center gap-1.5">
                <mat-icon class="text-xs text-neutral-600">location_on</mat-icon>
                <span>{{ store.settings().storeLocation }}</span>
              </div>
              <div class="flex items-center gap-1.5">
                <mat-icon class="text-xs text-neutral-600">mail</mat-icon>
                <span>{{ store.settings().contactEmail }}</span>
              </div>
            </div>
          </div>

          <!-- Quick Navigation -->
          <div class="grid grid-cols-2 sm:grid-cols-3 gap-8 text-xs font-mono">
            <div class="space-y-3">
              <div class="font-bold text-white uppercase tracking-wider">STOREFRONT</div>
              <ul class="space-y-2 text-neutral-400">
                <li><a href="#home" class="hover:text-white transition-colors">Home</a></li>
                <li><a href="#shop" class="hover:text-white transition-colors">Shop Shadow Eye</a></li>
                <li><a href="#featured" class="hover:text-white transition-colors">Collection</a></li>
                <li>
                  <button type="button" (click)="store.openSizeGuide()" class="hover:text-white transition-colors text-left">
                    Size Guide
                  </button>
                </li>
              </ul>
            </div>

            <div class="space-y-3">
              <div class="font-bold text-white uppercase tracking-wider">ABOUT &amp; POLICIES</div>
              <ul class="space-y-2 text-neutral-400">
                <li><a href="#about" class="hover:text-white transition-colors">Craft &amp; Fabric</a></li>
                <li><a href="#contact" class="hover:text-white transition-colors">Contact Styling</a></li>
                <li>
                  <button type="button" (click)="store.openReturnModal()" class="text-red-400 hover:text-red-300 transition-colors text-left flex items-center gap-1 font-semibold">
                    <mat-icon class="text-xs">assignment_return</mat-icon>
                    <span>24h Return Claim</span>
                  </button>
                </li>
                <li>
                  <a [href]="'https://wa.me/' + store.fullWhatsAppNumber()" target="_blank" rel="noopener noreferrer" class="hover:text-emerald-400 transition-colors flex items-center gap-1">
                    <span>WhatsApp VIP</span>
                    <mat-icon class="text-xs">north_east</mat-icon>
                  </a>
                </li>
              </ul>
            </div>

            <div class="space-y-3">
              <div class="font-bold text-white uppercase tracking-wider">MANAGEMENT</div>
              <ul class="space-y-2 text-neutral-400">
                <li>
                  <button
                    type="button"
                    (click)="store.openAdmin()"
                    class="text-red-400 hover:text-red-300 transition-colors flex items-center gap-1 text-left font-bold"
                  >
                    <mat-icon class="text-xs">tune</mat-icon>
                    <span>Admin Studio</span>
                  </button>
                </li>
                <li>
                  <button
                    type="button"
                    (click)="store.openCart()"
                    class="hover:text-white transition-colors text-left"
                  >
                    View Bag ({{ store.cartCount() }})
                  </button>
                </li>
                <li class="pt-2">
                  <span class="inline-block px-2 py-0.5 rounded bg-red-950/60 border border-red-500/30 text-[10px] text-red-400 uppercase font-bold tracking-wider">
                    NO COD · PREPAID ONLY
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <!-- Bottom Strip -->
        <div class="pt-8 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-mono text-neutral-500">
          <div>
            &copy; 2026 GODS PRINTS APPAREL CO. ALL RIGHTS RESERVED.
          </div>
          <div class="flex items-center gap-4 flex-wrap">
            <span class="text-neutral-400">DROP 01 // OVERSIZED CAPSULE</span>
            <span>·</span>
            <button
              type="button"
              (click)="store.openReturnModal()"
              class="text-neutral-400 hover:text-white underline decoration-neutral-700"
            >
              24h Claim Window
            </button>
            <span>·</span>
            <button
              type="button"
              (click)="store.openAdmin()"
              class="text-neutral-400 hover:text-white underline decoration-neutral-700"
            >
              Admin Studio
            </button>
          </div>
        </div>

      </div>
    </footer>
  `,
})
export class FooterComponent {
  readonly store = inject(StoreService);
}
