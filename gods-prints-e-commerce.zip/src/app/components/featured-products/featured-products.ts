import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';
import { Product } from '../../models/product.model';
import { formatCurrencyINR } from '../../utils/store-logic';

@Component({
  selector: 'app-featured-products',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <section id="featured" class="py-20 bg-[#070709] border-b border-white/5 scroll-mt-20">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Header -->
        <div class="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
          <div>
            <div class="text-xs font-mono uppercase tracking-widest text-red-500 mb-1">
              CURATED CAPSULE // 2026
            </div>
            <h2 class="font-display text-3xl sm:text-4xl font-black uppercase text-white tracking-tight">
              FEATURED STREETWEAR
            </h2>
          </div>
          <p class="text-xs font-mono text-neutral-400 max-w-xs sm:text-right">
            Heavyweight luxury cuts built with pre-shrunk Japanese loopback cotton.
          </p>
        </div>

        <!-- Product Cards Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          @for (prod of (store.featuredProducts().length > 0 ? store.featuredProducts() : store.publishedProducts()); track prod.id) {
            <div 
              class="group bg-[#0d0d12] rounded-2xl border border-white/10 hover:border-red-500/40 transition-all duration-300 overflow-hidden flex flex-col cursor-pointer focus:outline-none focus:ring-2 focus:ring-red-500"
              role="button"
              tabindex="0"
              (click)="selectAndScrollToProduct(prod)"
              (keydown.enter)="selectAndScrollToProduct(prod)"
            >
              <!-- Card Image Area (65-75% height as per retail guidelines) -->
              <div class="relative aspect-[4/5] bg-[#09090c] p-4 flex items-center justify-center overflow-hidden border-b border-white/5">
                <img
                  [src]="prod.frontImage"
                  [alt]="prod.name"
                  class="max-w-full max-h-full w-auto h-auto object-contain img-sharp select-none pointer-events-none"
                  referrerpolicy="no-referrer"
                />

                <!-- Top Badge -->
                <div class="absolute top-3 left-3 px-2.5 py-1 rounded bg-black/85 backdrop-blur-md border border-white/10 text-[10px] font-mono tracking-widest text-neutral-300">
                  {{ prod.badge || prod.category }}
                </div>

                <!-- Hover Quick View Action Button -->
                <div class="absolute inset-x-4 bottom-4 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div
                    class="w-full py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors shadow-lg shadow-red-600/30 flex items-center justify-center gap-1.5"
                  >
                    <span>View Piece &amp; Sizing</span>
                    <mat-icon class="text-sm">arrow_forward</mat-icon>
                  </div>
                </div>
              </div>

              <!-- Card Content Area -->
              <div class="p-5 flex-1 flex flex-col justify-between space-y-3">
                <div>
                  <div class="text-[11px] font-mono uppercase text-neutral-500 tracking-wider">
                    {{ prod.gsm }} GSM · {{ prod.color }}
                  </div>
                  <h3 class="font-display text-base font-bold text-white group-hover:text-red-400 transition-colors mt-0.5">
                    {{ prod.name }}
                  </h3>
                  <p class="text-xs text-neutral-400 line-clamp-2 mt-1 leading-relaxed">
                    {{ prod.subtitle }}
                  </p>
                </div>

                <!-- Price and Size strip -->
                <div class="pt-3 border-t border-white/5 flex items-center justify-between">
                  <div>
                    <span class="text-base font-bold text-white font-mono tabular-nums">
                      {{ formatCurrencyINR(prod.basePrice) }}
                    </span>
                    <span class="text-[10px] font-mono text-neutral-500 ml-1">
                      (3XL {{ formatCurrencyINR(prod.price3XL) }})
                    </span>
                  </div>

                  <span class="text-[11px] font-mono text-neutral-400 group-hover:text-white transition-colors">
                    7 Sizes Available →
                  </span>
                </div>
              </div>

            </div>
          }
        </div>

      </div>
    </section>
  `,
})
export class FeaturedProductsComponent {
  readonly store = inject(StoreService);

  formatCurrencyINR(val: number) {
    return formatCurrencyINR(val);
  }

  selectAndScrollToProduct(prod: Product) {
    this.store.selectProduct(prod.id);
    const element = document.getElementById('shop');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }
}
