import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-size-guide-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (store.isSizeGuideOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
        <!-- Backdrop Button -->
        <button
          type="button"
          class="fixed inset-0 bg-black/80 backdrop-blur-sm cursor-default border-none w-full h-full"
          (click)="store.closeSizeGuide()"
          aria-label="Close size guide backdrop"
        ></button>

        <div 
          class="relative w-full max-w-2xl bg-[#0e0e13] border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8 z-10"
        >
          <!-- Header -->
          <div class="px-6 py-4 bg-[#14141a] border-b border-white/10 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-red-500">straighten</mat-icon>
              <h3 class="font-display text-base font-bold text-white uppercase tracking-wider">
                OVERSIZED HOODIE SIZE GUIDE
              </h3>
            </div>
            <button
              type="button"
              (click)="store.closeSizeGuide()"
              class="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center"
              aria-label="Close"
            >
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>

          <div class="p-6 space-y-5">
            <!-- Units Toggle -->
            <div class="flex items-center justify-between">
              <span class="text-xs font-mono text-neutral-400">
                Fit: <strong class="text-white">Oversized Drop Shoulder</strong> (True to street sizing)
              </span>
              <div class="flex bg-neutral-900 rounded-lg p-0.5 border border-neutral-800 text-xs font-mono">
                <button
                  type="button"
                  (click)="unit.set('in')"
                  [class]="unit() === 'in' ? 'bg-red-600 text-white font-bold' : 'text-neutral-400 hover:text-white'"
                  class="px-3 py-1 rounded transition-colors"
                >
                  Inches
                </button>
                <button
                  type="button"
                  (click)="unit.set('cm')"
                  [class]="unit() === 'cm' ? 'bg-red-600 text-white font-bold' : 'text-neutral-400 hover:text-white'"
                  class="px-3 py-1 rounded transition-colors"
                >
                  Centimeters
                </button>
              </div>
            </div>

            <!-- Size Chart Table -->
            <div class="overflow-x-auto rounded-xl border border-white/10 bg-[#09090c]">
              <table class="w-full text-xs font-mono text-left">
                <thead class="bg-[#14141b] text-neutral-300 uppercase border-b border-white/10">
                  <tr>
                    <th class="p-3 font-bold text-red-400">Size</th>
                    <th class="p-3">Chest Width</th>
                    <th class="p-3">Body Length</th>
                    <th class="p-3">Shoulder Drop</th>
                    <th class="p-3">Sleeve Length</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-white/5 text-neutral-300">
                  @for (row of sizeData; track row.size) {
                    <tr [class.bg-red-600/10]="store.selectedSize() === row.size" class="hover:bg-neutral-900/60 transition-colors">
                      <td class="p-3 font-bold text-white flex items-center gap-1.5">
                        <span>{{ row.size }}</span>
                        @if (store.selectedSize() === row.size) {
                          <span class="text-[9px] bg-red-600 text-white px-1.5 py-0.2 rounded font-mono">Selected</span>
                        }
                      </td>
                      <td class="p-3">{{ unit() === 'in' ? row.chestIn + '"' : row.chestCm + ' cm' }}</td>
                      <td class="p-3">{{ unit() === 'in' ? row.lengthIn + '"' : row.lengthCm + ' cm' }}</td>
                      <td class="p-3">{{ unit() === 'in' ? row.shoulderIn + '"' : row.shoulderCm + ' cm' }}</td>
                      <td class="p-3">{{ unit() === 'in' ? row.sleeveIn + '"' : row.sleeveCm + ' cm' }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>

            <!-- Fitting Recommendation -->
            <div class="p-4 rounded-xl bg-neutral-900/60 border border-white/5 space-y-2 text-xs font-mono text-neutral-400">
              <p class="font-bold text-neutral-200 uppercase tracking-wide">Fitting Advice:</p>
              <ul class="list-disc pl-4 space-y-1">
                <li>For the signature oversized Tokyo drape, select your regular size.</li>
                <li>For a standard tailored fit, choose one size down.</li>
                <li>3XL features widened chest and reinforced armhole geometry for maximum comfort.</li>
              </ul>
            </div>
          </div>

          <div class="px-6 py-3 bg-[#14141a] border-t border-white/10 flex justify-end">
            <button
              type="button"
              (click)="store.closeSizeGuide()"
              class="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-mono uppercase tracking-wider"
            >
              Close Guide
            </button>
          </div>
        </div>
      </div>
    }
  `,
})
export class SizeGuideModalComponent {
  readonly store = inject(StoreService);
  readonly unit = signal<'in' | 'cm'>('in');

  readonly sizeData = [
    { size: 'XS', chestIn: 42, lengthIn: 27, shoulderIn: 22, sleeveIn: 22.5, chestCm: 107, lengthCm: 69, shoulderCm: 56, sleeveCm: 57 },
    { size: 'S',  chestIn: 44, lengthIn: 28, shoulderIn: 23, sleeveIn: 23,   chestCm: 112, lengthCm: 71, shoulderCm: 58, sleeveCm: 58 },
    { size: 'M',  chestIn: 46, lengthIn: 29, shoulderIn: 24, sleeveIn: 23.5, chestCm: 117, lengthCm: 74, shoulderCm: 61, sleeveCm: 60 },
    { size: 'L',  chestIn: 48, lengthIn: 30, shoulderIn: 25, sleeveIn: 24,   chestCm: 122, lengthCm: 76, shoulderCm: 63, sleeveCm: 61 },
    { size: 'XL', chestIn: 50, lengthIn: 31, shoulderIn: 26, sleeveIn: 24.5, chestCm: 127, lengthCm: 79, shoulderCm: 66, sleeveCm: 62 },
    { size: 'XXL',chestIn: 52, lengthIn: 32, shoulderIn: 27, sleeveIn: 25,   chestCm: 132, lengthCm: 81, shoulderCm: 69, sleeveCm: 63 },
    { size: '3XL',chestIn: 55, lengthIn: 33, shoulderIn: 28, sleeveIn: 25.5, chestCm: 140, lengthCm: 84, shoulderCm: 71, sleeveCm: 65 },
  ];
}
