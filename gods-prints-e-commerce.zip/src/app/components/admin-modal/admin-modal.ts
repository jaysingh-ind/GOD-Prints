import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';
import { Product } from '../../models/product.model';
import { formatCurrencyINR, validateImageFile } from '../../utils/store-logic';

@Component({
  selector: 'app-admin-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.isAdminOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
        <!-- Backdrop Button -->
        <button
          type="button"
          class="fixed inset-0 bg-black/90 backdrop-blur-md cursor-default border-none w-full h-full"
          (click)="store.closeAdmin()"
          aria-label="Close admin modal backdrop"
        ></button>

        <div class="relative w-full max-w-5xl bg-[#0d0d12] border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-6 z-10 max-h-[92vh] flex flex-col">
          
          <!-- ============================================== -->
          <!-- 1. ADMIN HEADER                                -->
          <!-- ============================================== -->
          <div class="px-6 py-4 bg-[#121219] border-b border-white/10 flex items-center justify-between shrink-0">
            <div class="flex items-center gap-3">
              <div class="w-8 h-8 rounded-lg bg-red-600/20 text-red-500 border border-red-500/30 flex items-center justify-center">
                <mat-icon class="text-lg">tune</mat-icon>
              </div>
              <div>
                <h2 class="font-display text-sm sm:text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <span>GODS PRINTS // ADMIN STUDIO</span>
                  @if (store.isAdminAuthenticated()) {
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      AUTHENTICATED
                    </span>
                  }
                </h2>
                <p class="text-[11px] font-mono text-neutral-400">
                  Product Catalog, Uncompressed Image Storage &amp; WhatsApp Settings
                </p>
              </div>
            </div>

            <div class="flex items-center gap-2">
              @if (store.isAdminAuthenticated()) {
                <button
                  type="button"
                  (click)="store.adminLogout()"
                  class="px-3 py-1.5 rounded-lg border border-neutral-700 hover:border-red-500 text-neutral-300 hover:text-white text-xs font-mono transition-colors flex items-center gap-1"
                >
                  <mat-icon class="text-sm">logout</mat-icon>
                  <span class="hidden sm:inline">Lock / Logout</span>
                </button>
              }
              <button
                type="button"
                (click)="store.closeAdmin()"
                class="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
                aria-label="Close Admin Modal"
              >
                <mat-icon class="text-sm">close</mat-icon>
              </button>
            </div>
          </div>

          <!-- ============================================== -->
          <!-- 2. AUTHENTICATION LOCK SCREEN (IF NOT AUTH)    -->
          <!-- ============================================== -->
          @if (!store.isAdminAuthenticated()) {
            <div class="p-8 sm:p-12 flex-1 flex items-center justify-center">
              <div class="w-full max-w-md bg-[#111117] border border-white/10 rounded-2xl p-6 sm:p-8 space-y-6 text-center shadow-xl">
                <div class="w-14 h-14 rounded-2xl bg-neutral-900 border border-white/10 flex items-center justify-center mx-auto text-red-500">
                  <mat-icon class="text-2xl">lock</mat-icon>
                </div>

                <div class="space-y-1.5">
                  <h3 class="font-display text-xl font-bold text-white uppercase tracking-wide">
                    Owner Access Verification
                  </h3>
                  <p class="text-xs font-mono text-neutral-400 leading-relaxed">
                    Admin Studio is protected to prevent unauthorized modifications to catalog, pricing, and orders.
                  </p>
                </div>

                <form (ngSubmit)="verifyPin()" class="space-y-4">
                  <div class="space-y-1 text-left">
                    <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Enter Admin Access PIN</span>
                    <input
                      #pinInput
                      type="password"
                      placeholder="Enter PIN (Default: gods2026)"
                      [value]="enteredPin()"
                      (input)="enteredPin.set(pinInput.value)"
                      class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none tracking-widest text-center"
                    />
                    @if (store.adminAuthError()) {
                      <span class="text-xs font-mono text-red-400 block pt-1">
                        {{ store.adminAuthError() }}
                      </span>
                    }
                  </div>

                  <button
                    type="submit"
                    class="w-full h-11 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-red-600/20 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <mat-icon class="text-sm">vpn_key</mat-icon>
                    <span>UNLOCK ADMIN STUDIO</span>
                  </button>
                </form>

                <div class="text-[11px] font-mono text-neutral-500 border-t border-white/5 pt-4">
                  Default setup PIN: <strong class="text-neutral-300">gods2026</strong> · Can be changed in settings
                </div>
              </div>
            </div>

          } @else {
            <!-- ============================================== -->
            <!-- 3. MAIN ADMIN TABS & WORKSPACE                 -->
            <!-- ============================================== -->
            
            <!-- Navigation Sub-bar -->
            <div class="flex items-center gap-2 px-6 py-2 bg-[#0a0a0e] border-b border-white/5 overflow-x-auto shrink-0">
              <button
                type="button"
                (click)="activeTab.set('catalog')"
                [class]="activeTab() === 'catalog' ? 'bg-neutral-800 text-white border-white/20' : 'text-neutral-400 hover:text-white border-transparent'"
                class="px-3.5 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <mat-icon class="text-base text-red-500">inventory_2</mat-icon>
                <span>Products Catalog ({{ store.products().length }})</span>
              </button>

              <button
                type="button"
                (click)="activeTab.set('editor')"
                [class]="activeTab() === 'editor' ? 'bg-neutral-800 text-white border-white/20' : 'text-neutral-400 hover:text-white border-transparent'"
                class="px-3.5 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <mat-icon class="text-base text-blue-400">edit_note</mat-icon>
                <span>Edit Piece: {{ activeProduct().name }}</span>
              </button>

              <button
                type="button"
                (click)="activeTab.set('whatsapp')"
                [class]="activeTab() === 'whatsapp' ? 'bg-neutral-800 text-white border-white/20' : 'text-neutral-400 hover:text-white border-transparent'"
                class="px-3.5 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <mat-icon class="text-base text-emerald-400">chat</mat-icon>
                <span>WhatsApp &amp; Contact</span>
              </button>

              <button
                type="button"
                (click)="activeTab.set('policy')"
                [class]="activeTab() === 'policy' ? 'bg-neutral-800 text-white border-white/20' : 'text-neutral-400 hover:text-white border-transparent'"
                class="px-3.5 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <mat-icon class="text-base text-yellow-500">policy</mat-icon>
                <span>Payment &amp; 24h Returns</span>
              </button>

              <button
                type="button"
                (click)="activeTab.set('storage')"
                [class]="activeTab() === 'storage' ? 'bg-neutral-800 text-white border-white/20' : 'text-neutral-400 hover:text-white border-transparent'"
                class="px-3.5 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <mat-icon class="text-base text-purple-400">cloud_done</mat-icon>
                <span>Cloud &amp; Security</span>
              </button>
            </div>

            <!-- Tab Content Viewport -->
            <div class="flex-1 overflow-y-auto p-6 space-y-6">
              
              <!-- ============================================== -->
              <!-- TAB 1: PRODUCTS CATALOG                        -->
              <!-- ============================================== -->
              @if (activeTab() === 'catalog') {
                <div class="space-y-6">
                  
                  <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-[#111117] border border-white/10 rounded-2xl p-4">
                    <div>
                      <h3 class="font-display text-base font-bold text-white uppercase">Product Management</h3>
                      <p class="text-xs font-mono text-neutral-400">
                        Add unlimited pieces, manage publishing status, prices, and upload high-resolution photos.
                      </p>
                    </div>

                    <button
                      type="button"
                      (click)="showCreateModal.set(true)"
                      class="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors flex items-center gap-2 shrink-0 shadow-lg shadow-red-600/20 cursor-pointer"
                    >
                      <mat-icon class="text-sm">add_circle</mat-icon>
                      <span>+ ADD NEW PRODUCT</span>
                    </button>
                  </div>

                  <!-- Product Items List -->
                  <div class="space-y-3">
                    @for (p of store.products(); track p.id) {
                      <div class="p-4 rounded-xl bg-[#111117] border border-white/10 flex flex-col md:flex-row md:items-center justify-between gap-4">
                        
                        <!-- Thumbnail & Info -->
                        <div class="flex items-center gap-4 min-w-0">
                          <div class="w-16 h-16 rounded-xl bg-[#09090c] border border-white/10 overflow-hidden flex items-center justify-center p-1 shrink-0">
                            <img
                              [src]="p.frontImage"
                              [alt]="p.name"
                              class="w-full h-full object-contain img-sharp"
                              referrerpolicy="no-referrer"
                            />
                          </div>

                          <div class="min-w-0 space-y-1">
                            <div class="flex items-center gap-2">
                              <h4 class="text-sm font-bold text-white truncate font-display">{{ p.name }}</h4>
                              <!-- Status badge -->
                              @if (p.isPublished !== false) {
                                <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                                  LIVE IN SHOP
                                </span>
                              } @else {
                                <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-neutral-800 text-neutral-400 border border-white/10">
                                  DRAFT (HIDDEN)
                                </span>
                              }
                              @if (p.inStock) {
                                <span class="text-[10px] font-mono text-emerald-400">IN STOCK</span>
                              } @else {
                                <span class="text-[10px] font-mono text-red-400">SOLD OUT</span>
                              }
                            </div>

                            <div class="text-xs font-mono text-neutral-400 flex items-center gap-2">
                              <span>{{ formatCurrency(p.basePrice) }} (3XL {{ formatCurrency(p.price3XL) }})</span>
                              <span>·</span>
                              <span>{{ p.gsm }} GSM {{ p.color }}</span>
                              <span>·</span>
                              <span class="text-neutral-500">{{ p.category }}</span>
                            </div>
                          </div>
                        </div>

                        <!-- Action Buttons -->
                        <div class="flex items-center gap-2 shrink-0 pt-2 md:pt-0 border-t md:border-t-0 border-white/5">
                          <!-- Edit Details -->
                          <button
                            type="button"
                            (click)="selectForEdit(p)"
                            class="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-700 hover:border-white text-white text-xs font-mono transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <mat-icon class="text-sm">edit</mat-icon>
                            <span>Edit &amp; Photos</span>
                          </button>

                          <!-- Toggle Publish -->
                          <button
                            type="button"
                            (click)="store.togglePublishProduct(p.id)"
                            [class]="p.isPublished !== false ? 'border-neutral-800 text-neutral-300 hover:text-white' : 'border-emerald-500/50 text-emerald-400 hover:bg-emerald-950/20'"
                            class="px-3 py-1.5 rounded-lg bg-neutral-900 border text-xs font-mono transition-colors flex items-center gap-1 cursor-pointer"
                            [title]="p.isPublished !== false ? 'Hide from shop' : 'Publish to shop'"
                          >
                            <mat-icon class="text-sm">{{ p.isPublished !== false ? 'visibility_off' : 'visibility' }}</mat-icon>
                            <span>{{ p.isPublished !== false ? 'Unpublish' : 'Publish' }}</span>
                          </button>

                          <!-- Delete -->
                          <button
                            type="button"
                            (click)="confirmDeleteProduct(p)"
                            class="p-1.5 rounded-lg bg-neutral-900 border border-neutral-800 hover:border-red-500 text-neutral-500 hover:text-red-400 transition-colors cursor-pointer"
                            title="Delete Product"
                            aria-label="Delete Product"
                          >
                            <mat-icon class="text-base">delete</mat-icon>
                          </button>
                        </div>

                      </div>
                    }
                  </div>

                </div>
              }

              <!-- ============================================== -->
              <!-- TAB 2: PRODUCT EDITOR (ACTIVE PIECE)           -->
              <!-- ============================================== -->
              @if (activeTab() === 'editor') {
                <div class="space-y-6">
                  
                  <div class="flex items-center justify-between border-b border-white/10 pb-4">
                    <div>
                      <span class="text-xs font-mono text-red-500 uppercase tracking-widest">PRODUCT EDITOR</span>
                      <h3 class="font-display text-xl font-bold text-white uppercase">{{ activeProduct().name }}</h3>
                    </div>

                    <div class="flex items-center gap-2">
                      <button
                        type="button"
                        (click)="activeTab.set('catalog')"
                        class="px-3 py-1.5 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white text-xs font-mono transition-colors"
                      >
                        ← Back to Catalog
                      </button>
                    </div>
                  </div>

                  <!-- 1. DUAL HIGH-RESOLUTION IMAGE UPLOAD SECTION -->
                  <div class="p-5 rounded-2xl bg-[#111117] border border-white/10 space-y-4">
                    <div class="flex items-center justify-between">
                      <div class="flex items-center gap-2">
                        <mat-icon class="text-red-500">photo_library</mat-icon>
                        <h4 class="text-xs font-mono font-bold uppercase text-white tracking-wider">
                          High-Resolution Image Studio (100% Original Quality)
                        </h4>
                      </div>
                      <span class="text-[11px] font-mono text-neutral-400">
                        Direct upload · object-fit: contain · Preserved in IndexedDB
                      </span>
                    </div>

                    <!-- Front & Back Image Slots -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                      
                      <!-- FRONT VIEW -->
                      <div class="p-4 rounded-xl bg-[#09090c] border border-white/10 space-y-3">
                        <div class="flex items-center justify-between">
                          <span class="text-xs font-mono font-bold text-white">FRONT VIEW</span>
                          <span class="text-[10px] font-mono" [class]="activeProduct().frontUploaded ? 'text-emerald-400' : 'text-neutral-500'">
                            {{ activeProduct().frontUploaded ? 'Custom Photo' : 'Default Asset' }}
                          </span>
                        </div>

                        <div class="relative aspect-[4/5] rounded-lg bg-[#060608] border border-white/10 overflow-hidden flex items-center justify-center p-2">
                          <img
                            [src]="activeProduct().frontImage"
                            alt="Front Preview"
                            class="max-w-full max-h-full w-auto h-auto object-contain img-sharp"
                            referrerpolicy="no-referrer"
                          />
                        </div>

                        <input #frontInput type="file" accept="image/*" class="hidden" (change)="handleImageFile($event, 'front')" />
                        
                        <div class="flex gap-2">
                          <button
                            type="button"
                            (click)="frontInput.click()"
                            class="flex-1 h-9 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <mat-icon class="text-sm">cloud_upload</mat-icon>
                            <span>{{ activeProduct().frontUploaded ? 'Replace Front' : 'Upload Front' }}</span>
                          </button>
                          @if (activeProduct().frontUploaded) {
                            <button
                              type="button"
                              (click)="store.deleteProductImage(activeProduct().id, 'front')"
                              class="px-3 h-9 rounded-lg border border-red-900/60 hover:border-red-600 text-red-400 text-xs font-mono transition-colors"
                            >
                              Reset
                            </button>
                          }
                        </div>
                        <p class="text-[10px] font-mono text-neutral-500 truncate text-center">
                          {{ activeProduct().frontImageName || 'PNG, JPG, WEBP up to 25MB' }}
                        </p>
                      </div>

                      <!-- BACK VIEW -->
                      <div class="p-4 rounded-xl bg-[#09090c] border border-white/10 space-y-3">
                        <div class="flex items-center justify-between">
                          <span class="text-xs font-mono font-bold text-white">BACK VIEW</span>
                          <span class="text-[10px] font-mono" [class]="activeProduct().backUploaded ? 'text-emerald-400' : 'text-neutral-500'">
                            {{ activeProduct().backUploaded ? 'Custom Photo' : 'Default Asset' }}
                          </span>
                        </div>

                        <div class="relative aspect-[4/5] rounded-lg bg-[#060608] border border-white/10 overflow-hidden flex items-center justify-center p-2">
                          <img
                            [src]="activeProduct().backImage"
                            alt="Back Preview"
                            class="max-w-full max-h-full w-auto h-auto object-contain img-sharp"
                            referrerpolicy="no-referrer"
                          />
                        </div>

                        <input #backInput type="file" accept="image/*" class="hidden" (change)="handleImageFile($event, 'back')" />
                        
                        <div class="flex gap-2">
                          <button
                            type="button"
                            (click)="backInput.click()"
                            class="flex-1 h-9 rounded-lg bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <mat-icon class="text-sm">cloud_upload</mat-icon>
                            <span>{{ activeProduct().backUploaded ? 'Replace Back' : 'Upload Back' }}</span>
                          </button>
                          @if (activeProduct().backUploaded) {
                            <button
                              type="button"
                              (click)="store.deleteProductImage(activeProduct().id, 'back')"
                              class="px-3 h-9 rounded-lg border border-red-900/60 hover:border-red-600 text-red-400 text-xs font-mono transition-colors"
                            >
                              Reset
                            </button>
                          }
                        </div>
                        <p class="text-[10px] font-mono text-neutral-500 truncate text-center">
                          {{ activeProduct().backImageName || 'PNG, JPG, WEBP up to 25MB' }}
                        </p>
                      </div>

                    </div>
                  </div>

                  <!-- 2. PRODUCT DETAILS & PRICING FORM -->
                  <form [formGroup]="editForm" (ngSubmit)="saveActiveProduct()" class="p-5 rounded-2xl bg-[#111117] border border-white/10 space-y-4">
                    <h4 class="text-xs font-mono font-bold uppercase text-white tracking-wider flex items-center gap-2">
                      <mat-icon class="text-sm text-red-500">sell</mat-icon>
                      <span>Specifications, Sizes &amp; Pricing</span>
                    </h4>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Product Name *</span>
                        <input type="text" formControlName="name" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Category *</span>
                        <input type="text" formControlName="category" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Price (XS to XXL) ₹ *</span>
                        <input type="number" formControlName="basePrice" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Price for 3XL ₹ *</span>
                        <input type="number" formControlName="price3XL" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Color Shade *</span>
                        <input type="text" formControlName="color" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Fabric Weight (GSM)</span>
                        <input type="number" formControlName="gsm" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Cut &amp; Fit</span>
                        <input type="text" formControlName="fit" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>
                    </div>

                    <div class="space-y-1">
                      <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Subtitle / Summary</span>
                      <input type="text" formControlName="subtitle" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                    </div>

                    <div class="space-y-1">
                      <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Description</span>
                      <textarea rows="3" formControlName="description" class="w-full p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono resize-none"></textarea>
                    </div>

                    <!-- Toggles -->
                    <div class="flex flex-wrap gap-4 pt-2">
                      <label class="flex items-center gap-2 cursor-pointer text-xs font-mono text-neutral-300">
                        <input type="checkbox" formControlName="inStock" class="w-4 h-4 rounded text-red-600 focus:ring-0" />
                        <span>In Stock (Available to Order)</span>
                      </label>
                      <label class="flex items-center gap-2 cursor-pointer text-xs font-mono text-neutral-300">
                        <input type="checkbox" formControlName="isPublished" class="w-4 h-4 rounded text-red-600 focus:ring-0" />
                        <span>Published (Live in Shop)</span>
                      </label>
                      <label class="flex items-center gap-2 cursor-pointer text-xs font-mono text-neutral-300">
                        <input type="checkbox" formControlName="isFeatured" class="w-4 h-4 rounded text-red-600 focus:ring-0" />
                        <span>Featured in Capsule Section</span>
                      </label>
                    </div>

                    <div class="pt-3">
                      <button
                        type="submit"
                        [disabled]="editForm.invalid"
                        class="w-full sm:w-auto px-6 h-11 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-600/20"
                      >
                        <mat-icon class="text-sm">save</mat-icon>
                        <span>SAVE PRODUCT CHANGES</span>
                      </button>
                    </div>
                  </form>

                </div>
              }

              <!-- ============================================== -->
              <!-- TAB 3: WHATSAPP & CONTACT SETTINGS             -->
              <!-- ============================================== -->
              @if (activeTab() === 'whatsapp') {
                <div class="space-y-6">
                  
                  <div class="p-5 rounded-2xl bg-[#111117] border border-white/10 space-y-4">
                    <h3 class="font-display text-base font-bold text-white uppercase flex items-center gap-2">
                      <mat-icon class="text-[#25D366]">chat</mat-icon>
                      <span>WhatsApp Business &amp; Country Code Settings</span>
                    </h3>
                    <p class="text-xs font-mono text-neutral-400">
                      Configure your official store WhatsApp number. Every "Order via WhatsApp", "Chat on WhatsApp", and "Return Request" button uses this exact verified number.
                    </p>

                    <form [formGroup]="whatsappForm" (ngSubmit)="saveWhatsAppSettings()" class="space-y-4">
                      
                      <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div class="space-y-1">
                          <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Country Code *</span>
                          <select formControlName="countryCode" class="w-full h-11 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono">
                            <option value="+91">+91 (India)</option>
                            <option value="+1">+1 (USA / Canada)</option>
                            <option value="+44">+44 (United Kingdom)</option>
                            <option value="+971">+971 (United Arab Emirates)</option>
                            <option value="+61">+61 (Australia)</option>
                            <option value="+81">+81 (Japan)</option>
                            <option value="+65">+65 (Singapore)</option>
                            <option value="+49">+49 (Germany)</option>
                          </select>
                        </div>

                        <div class="sm:col-span-2 space-y-1">
                          <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">WhatsApp Number *</span>
                          <input
                            type="text"
                            formControlName="whatsappPhone"
                            placeholder="e.g. 9876543210"
                            class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                          />
                          <span class="text-[10px] text-neutral-500 font-mono">Digits only without leading 0</span>
                        </div>
                      </div>

                      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                          <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Official Contact Email *</span>
                          <input type="email" formControlName="contactEmail" class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                        </div>

                        <div class="space-y-1">
                          <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Official Instagram *</span>
                          <input type="text" formControlName="instagram" placeholder="e.g. @godsprints" class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                        </div>
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Store Location (Genuine Atelier)</span>
                        <input type="text" formControlName="storeLocation" placeholder="e.g. India Studio · Direct-to-Consumer Streetwear" class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Brand Statement / Bio</span>
                        <textarea rows="3" formControlName="brandBio" class="w-full p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono resize-none"></textarea>
                      </div>

                      <div class="pt-2">
                        <button
                          type="submit"
                          class="px-6 h-11 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-600/20"
                        >
                          <mat-icon class="text-sm">save</mat-icon>
                          <span>SAVE WHATSAPP &amp; CONTACT DETAILS</span>
                        </button>
                      </div>

                    </form>
                  </div>

                </div>
              }

              <!-- ============================================== -->
              <!-- TAB 4: PAYMENT & RETURN POLICY                 -->
              <!-- ============================================== -->
              @if (activeTab() === 'policy') {
                <div class="space-y-6">
                  
                  <div class="p-5 rounded-2xl bg-[#111117] border border-white/10 space-y-4">
                    <h3 class="font-display text-base font-bold text-white uppercase flex items-center gap-2">
                      <mat-icon class="text-yellow-500">policy</mat-icon>
                      <span>Prepaid Payment &amp; 24-Hour Return Policy Settings</span>
                    </h3>

                    <form [formGroup]="policyForm" (ngSubmit)="savePolicySettings()" class="space-y-4">
                      
                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Payment Notice Banner</span>
                        <input type="text" formControlName="paymentNotice" class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                      </div>

                      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                          <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Official UPI ID for Payments</span>
                          <input type="text" formControlName="paymentUpiId" placeholder="e.g. godsprints@upi" class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                        </div>

                        <div class="space-y-1">
                          <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Return Claim Window (Hours)</span>
                          <input type="number" formControlName="returnHours" class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                        </div>
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Payment Instructions for Customers</span>
                        <textarea rows="3" formControlName="paymentInstructions" class="w-full p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono resize-none"></textarea>
                      </div>

                      <div class="space-y-1">
                        <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">24-Hour Return Policy Text</span>
                        <textarea rows="4" formControlName="returnPolicyText" class="w-full p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono resize-none"></textarea>
                      </div>

                      <div class="pt-2">
                        <button
                          type="submit"
                          class="px-6 h-11 rounded-xl bg-red-600 hover:bg-red-500 text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-600/20"
                        >
                          <mat-icon class="text-sm">save</mat-icon>
                          <span>SAVE POLICIES</span>
                        </button>
                      </div>

                    </form>
                  </div>

                </div>
              }

              <!-- ============================================== -->
              <!-- TAB 5: CLOUD & SECURITY SETUP                   -->
              <!-- ============================================== -->
              @if (activeTab() === 'storage') {
                <div class="space-y-6">
                  
                  <div class="p-6 rounded-2xl bg-[#111117] border border-white/10 space-y-4">
                    <div class="flex items-center gap-3">
                      <div class="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 flex items-center justify-center">
                        <mat-icon class="text-xl">storage</mat-icon>
                      </div>
                      <div>
                        <h3 class="font-display text-base font-bold text-white uppercase">Data Engine &amp; Cloud Storage Architecture</h3>
                        <p class="text-xs font-mono text-neutral-400">
                          Dual-layer persistence: Node Express Server Engine + Browser IndexedDB
                        </p>
                      </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                      <div class="p-4 rounded-xl bg-[#09090c] border border-white/10 space-y-2">
                        <div class="flex items-center gap-2 text-emerald-400 text-xs font-mono font-bold">
                          <mat-icon class="text-base">check_circle</mat-icon>
                          <span>Server Disk Persistence (/data)</span>
                        </div>
                        <p class="text-[11px] font-mono text-neutral-400 leading-relaxed">
                          Products and settings are persisted to disk JSON files on the server (<code class="text-neutral-300">/data/products.json</code> and <code class="text-neutral-300">/data/settings.json</code>). They remain available across all page refreshes and browser restarts.
                        </p>
                      </div>

                      <div class="p-4 rounded-xl bg-[#09090c] border border-white/10 space-y-2">
                        <div class="flex items-center gap-2 text-emerald-400 text-xs font-mono font-bold">
                          <mat-icon class="text-base">check_circle</mat-icon>
                          <span>IndexedDB Uncompressed Storage</span>
                        </div>
                        <p class="text-[11px] font-mono text-neutral-400 leading-relaxed">
                          High-resolution studio photos (up to 25MB) are preserved uncompressed in client IndexedDB storage without hitting localStorage 5MB size limits.
                        </p>
                      </div>
                    </div>

                    <!-- Cloud Setup Explanation -->
                    <div class="p-4 rounded-xl bg-neutral-900 border border-white/10 space-y-3">
                      <h4 class="text-xs font-mono font-bold text-white uppercase flex items-center gap-2">
                        <mat-icon class="text-sm text-yellow-500">cloud_queue</mat-icon>
                        <span>Need Multi-Device Cloud Sync?</span>
                      </h4>
                      <p class="text-xs font-mono text-neutral-400 leading-relaxed">
                        To synchronize products seamlessly across multiple store managers and computers with zero reliance on single-server disk, you can connect an external cloud database:
                      </p>
                      <ul class="text-[11px] font-mono text-neutral-300 space-y-1 list-disc list-inside">
                        <li><strong>PostgreSQL / Cloud SQL:</strong> For relational product tables and transactional order ledgers.</li>
                        <li><strong>Firebase Firestore:</strong> For real-time inventory updates and instant multi-device syncing.</li>
                        <li><strong>AWS S3 / Cloudflare R2:</strong> For CDN-backed original image hosting.</li>
                      </ul>
                    </div>

                    <!-- Factory Reset -->
                    <div class="pt-4 border-t border-white/5 flex items-center justify-between">
                      <div>
                        <h4 class="text-xs font-mono font-bold text-red-400 uppercase">Emergency Data Reset</h4>
                        <p class="text-[11px] font-mono text-neutral-500">Reset catalog and settings back to pristine verified drop specs.</p>
                      </div>
                      <button
                        type="button"
                        (click)="store.resetToDefaultData()"
                        class="px-4 py-2 rounded-xl border border-red-900/60 hover:border-red-600 bg-red-950/20 text-red-400 text-xs font-mono transition-colors cursor-pointer"
                      >
                        Reset Factory Specs
                      </button>
                    </div>

                  </div>

                </div>
              }

            </div>

            <!-- Modal Footer -->
            <div class="px-6 py-3.5 bg-[#0e0e13] border-t border-white/10 flex items-center justify-between shrink-0">
              <span class="text-xs font-mono text-neutral-500">
                Active Catalog: {{ store.publishedProducts().length }} Live Piece(s)
              </span>
              <button
                type="button"
                (click)="store.closeAdmin()"
                class="px-5 py-2 rounded-xl bg-white hover:bg-neutral-200 text-black text-xs font-mono font-bold uppercase tracking-wider transition-colors cursor-pointer"
              >
                Return to Storefront
              </button>
            </div>
          }

        </div>
      </div>

      <!-- ============================================== -->
      <!-- CREATE PRODUCT MODAL DIALOG                     -->
      <!-- ============================================== -->
      @if (showCreateModal()) {
        <div class="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div class="relative w-full max-w-lg bg-[#111117] border border-white/15 rounded-2xl p-6 space-y-4 shadow-2xl">
            <div class="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 class="font-display text-base font-bold text-white uppercase flex items-center gap-2">
                <mat-icon class="text-red-500">add_box</mat-icon>
                <span>Add New Streetwear Piece</span>
              </h3>
              <button type="button" (click)="showCreateModal.set(false)" class="text-neutral-400 hover:text-white">
                <mat-icon class="text-sm">close</mat-icon>
              </button>
            </div>

            <form [formGroup]="createForm" (ngSubmit)="handleCreateProduct()" class="space-y-3.5">
              <div class="space-y-1">
                <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Piece Title *</span>
                <input type="text" formControlName="name" placeholder="e.g. Cursed Energy Washed Tee" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Price (XS to XXL) ₹ *</span>
                  <input type="number" formControlName="basePrice" placeholder="1499" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                </div>
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Price (3XL) ₹ *</span>
                  <input type="number" formControlName="price3XL" placeholder="1599" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                </div>
              </div>

              <div class="grid grid-cols-2 gap-3">
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Category *</span>
                  <input type="text" formControlName="category" placeholder="Hoodies / Tees / Crewnecks" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                </div>
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Color Shade *</span>
                  <input type="text" formControlName="color" placeholder="e.g. Acid Washed Charcoal" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
                </div>
              </div>

              <div class="space-y-1">
                <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Short Subtitle</span>
                <input type="text" formControlName="subtitle" placeholder="420 GSM Drop-Shoulder French Terry" class="w-full h-10 px-3 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono" />
              </div>

              <div class="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  (click)="showCreateModal.set(false)"
                  class="px-4 py-2 rounded-xl bg-neutral-900 text-neutral-400 hover:text-white text-xs font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  [disabled]="createForm.invalid"
                  class="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-mono text-xs font-bold uppercase transition-colors"
                >
                  Create Piece
                </button>
              </div>
            </form>
          </div>
        </div>
      }

    }
  `,
})
export class AdminModalComponent {
  readonly store = inject(StoreService);
  private readonly fb = inject(FormBuilder);

  readonly activeTab = signal<'catalog' | 'editor' | 'whatsapp' | 'policy' | 'storage'>('catalog');
  readonly enteredPin = signal<string>('');
  readonly showCreateModal = signal<boolean>(false);

  readonly activeProduct = computed<Product>(() => this.store.activeProduct());

  // Forms
  readonly editForm = this.fb.group({
    name: [this.activeProduct().name, Validators.required],
    category: [this.activeProduct().category, Validators.required],
    color: [this.activeProduct().color, Validators.required],
    basePrice: [this.activeProduct().basePrice, [Validators.required, Validators.min(100)]],
    price3XL: [this.activeProduct().price3XL, [Validators.required, Validators.min(100)]],
    subtitle: [this.activeProduct().subtitle],
    gsm: [this.activeProduct().gsm],
    fit: [this.activeProduct().fit],
    description: [this.activeProduct().description],
    inStock: [this.activeProduct().inStock],
    isPublished: [this.activeProduct().isPublished !== false],
    isFeatured: [this.activeProduct().isFeatured],
  });

  readonly whatsappForm = this.fb.group({
    countryCode: [this.store.settings().countryCode, Validators.required],
    whatsappPhone: [this.store.settings().whatsappPhone, [Validators.required, Validators.minLength(7)]],
    contactEmail: [this.store.settings().contactEmail, [Validators.required, Validators.email]],
    instagram: [this.store.settings().instagram, Validators.required],
    storeLocation: [this.store.settings().storeLocation],
    brandBio: [this.store.settings().brandBio],
  });

  readonly policyForm = this.fb.group({
    paymentNotice: [this.store.settings().paymentNotice, Validators.required],
    paymentUpiId: [this.store.settings().paymentUpiId || ''],
    paymentInstructions: [this.store.settings().paymentInstructions, Validators.required],
    returnHours: [this.store.settings().returnHours || 24, Validators.required],
    returnPolicyText: [this.store.settings().returnPolicyText, Validators.required],
  });

  readonly createForm = this.fb.group({
    name: ['', Validators.required],
    category: ['Hoodies', Validators.required],
    color: ['Black', Validators.required],
    basePrice: [1499, [Validators.required, Validators.min(100)]],
    price3XL: [1599, [Validators.required, Validators.min(100)]],
    subtitle: ['420 GSM Drop-Shoulder French Terry'],
  });

  formatCurrency(amount: number) {
    return formatCurrencyINR(amount);
  }

  async verifyPin() {
    const pin = this.enteredPin().trim();
    if (!pin) return;
    await this.store.verifyAdminPin(pin);
  }

  selectForEdit(product: Product) {
    this.store.selectProduct(product.id);
    this.editForm.patchValue({
      name: product.name,
      category: product.category,
      color: product.color,
      basePrice: product.basePrice,
      price3XL: product.price3XL,
      subtitle: product.subtitle,
      gsm: product.gsm,
      fit: product.fit,
      description: product.description,
      inStock: product.inStock,
      isPublished: product.isPublished !== false,
      isFeatured: product.isFeatured,
    });
    this.activeTab.set('editor');
  }

  confirmDeleteProduct(product: Product) {
    if (confirm(`Are you sure you want to delete "${product.name}"?`)) {
      this.store.deleteProduct(product.id);
    }
  }

  handleImageFile(event: Event, view: 'front' | 'back') {
    const input = event.target as HTMLInputElement;
    if (!input.files || input.files.length === 0) return;

    const file = input.files[0];
    const validation = validateImageFile(file);
    if (!validation.valid) {
      this.store.showToast(validation.error || 'Invalid file');
      input.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (dataUrl) {
        this.store.uploadProductImage(this.activeProduct().id, view, dataUrl, file.name);
      }
    };
    reader.readAsDataURL(file);
    input.value = '';
  }

  saveActiveProduct() {
    if (this.editForm.invalid) return;

    const current = this.activeProduct();
    const val = this.editForm.value;

    const updated: Product = {
      ...current,
      name: val.name || current.name,
      category: val.category || current.category,
      color: val.color || current.color,
      basePrice: Number(val.basePrice) || current.basePrice,
      price3XL: Number(val.price3XL) || current.price3XL,
      subtitle: val.subtitle || current.subtitle,
      gsm: Number(val.gsm) || current.gsm,
      fit: val.fit || current.fit,
      description: val.description || current.description,
      inStock: val.inStock !== undefined ? !!val.inStock : current.inStock,
      isPublished: val.isPublished !== undefined ? !!val.isPublished : current.isPublished,
      isFeatured: val.isFeatured !== undefined ? !!val.isFeatured : current.isFeatured,
    };

    this.store.updateProduct(updated);
  }

  saveWhatsAppSettings() {
    if (this.whatsappForm.invalid) return;
    const val = this.whatsappForm.value;
    this.store.updateSettings({
      countryCode: val.countryCode || '+91',
      whatsappPhone: val.whatsappPhone || '9876543210',
      contactEmail: val.contactEmail || 'concierge@godsprints.in',
      instagram: val.instagram || '@godsprints',
      storeLocation: val.storeLocation || 'India Studio',
      brandBio: val.brandBio || '',
    });
  }

  savePolicySettings() {
    if (this.policyForm.invalid) return;
    const val = this.policyForm.value;
    this.store.updateSettings({
      paymentNotice: val.paymentNotice || 'PREPAID ORDERS ONLY · NO CASH ON DELIVERY',
      paymentUpiId: val.paymentUpiId || '',
      paymentInstructions: val.paymentInstructions || '',
      returnHours: Number(val.returnHours) || 24,
      returnPolicyText: val.returnPolicyText || '',
    });
  }

  handleCreateProduct() {
    if (this.createForm.invalid) return;
    const val = this.createForm.value;
    const created = this.store.addProduct({
      name: val.name || 'New Piece',
      category: val.category || 'Hoodies',
      color: val.color || 'Black',
      basePrice: Number(val.basePrice) || 1499,
      price3XL: Number(val.price3XL) || 1599,
      subtitle: val.subtitle || 'Premium Heavyweight Streetwear',
      isPublished: true,
      inStock: true,
      isFeatured: true,
    });
    this.showCreateModal.set(false);
    this.selectForEdit(created);
  }
}
