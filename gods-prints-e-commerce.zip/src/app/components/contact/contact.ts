import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-contact',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <section id="contact" class="py-24 bg-[#070709] border-b border-white/5 scroll-mt-20">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          <!-- Left Column: Concierge Info & WhatsApp Action -->
          <div class="lg:col-span-5 space-y-8">
            <div>
              <div class="text-xs font-mono uppercase tracking-widest text-red-500 mb-2 flex items-center gap-2">
                <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                GENUINE CLIENT SUPPORT
              </div>
              <h2 class="font-display text-3xl sm:text-4xl font-black uppercase text-white tracking-tight">
                CONTACT &amp; CONCIERGE
              </h2>
              <p class="text-xs sm:text-sm text-neutral-400 mt-3 leading-relaxed">
                Have questions regarding custom sizing, limited drop availability, or order status? Reach our dedicated atelier team directly via WhatsApp or email.
              </p>
            </div>

            <!-- Direct WhatsApp VIP Card -->
            <div class="p-6 rounded-2xl bg-[#0f0f15] border border-white/10 space-y-4">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-[#25D366]/20 border border-[#25D366]/30 flex items-center justify-center text-[#25D366]">
                  <mat-icon class="text-xl">chat</mat-icon>
                </div>
                <div>
                  <h4 class="text-xs font-mono font-bold text-white uppercase tracking-wider">
                    Instant WhatsApp Support
                  </h4>
                  <p class="text-[11px] text-neutral-400 font-mono">
                    {{ store.displayWhatsAppNumber() }}
                  </p>
                </div>
              </div>

              <p class="text-xs text-neutral-400 leading-relaxed font-mono">
                Order directly, inquire about fabric weights, or ask for custom sizing advice on WhatsApp.
              </p>

              <a
                [href]="'https://wa.me/' + store.fullWhatsAppNumber() + '?text=Hi%20GODS%20PRINTS,%20I%20have%20an%20inquiry%20regarding%20Drop%2001'"
                target="_blank"
                rel="noopener noreferrer"
                class="w-full h-11 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-mono text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-md shadow-[#25D366]/20 cursor-pointer"
              >
                <span>Chat on WhatsApp</span>
                <mat-icon class="text-sm">open_in_new</mat-icon>
              </a>
            </div>

            <!-- Return Policy Callout Card -->
            <div class="p-4 rounded-xl bg-[#111118] border border-white/5 space-y-2">
              <div class="flex items-center justify-between">
                <span class="text-xs font-mono font-bold text-yellow-400 flex items-center gap-1.5">
                  <mat-icon class="text-sm">assignment_return</mat-icon>
                  24-Hour Return Window
                </span>
                <button
                  type="button"
                  (click)="store.openReturnModal()"
                  class="text-[11px] font-mono text-red-400 hover:text-red-300 underline cursor-pointer"
                >
                  File Claim →
                </button>
              </div>
              <p class="text-[11px] font-mono text-neutral-400 leading-relaxed">
                Damaged or incorrect parcels are reviewed within 24 hours of delivery. Have your unboxing photos ready.
              </p>
            </div>

            <!-- Verified Contact Info Markers -->
            <div class="space-y-3 text-xs font-mono text-neutral-400 border-t border-white/5 pt-6">
              <div class="flex items-center gap-3">
                <mat-icon class="text-red-500 text-sm">schedule</mat-icon>
                <span>Dispatch Schedule: Monday – Saturday (Prepaid Orders Only)</span>
              </div>
              <div class="flex items-center gap-3">
                <mat-icon class="text-red-500 text-sm">mail</mat-icon>
                <span>Email Support: {{ store.settings().contactEmail }}</span>
              </div>
              <div class="flex items-center gap-3">
                <mat-icon class="text-red-500 text-sm">photo_camera</mat-icon>
                <span>Instagram: {{ store.settings().instagram }}</span>
              </div>
              <div class="flex items-center gap-3">
                <mat-icon class="text-red-500 text-sm">storefront</mat-icon>
                <span>Atelier: {{ store.settings().storeLocation }}</span>
              </div>
            </div>
          </div>

          <!-- Right Column: Interactive Contact Form -->
          <div class="lg:col-span-7">
            <div class="p-8 rounded-2xl bg-[#0d0d12] border border-white/10 shadow-xl">
              
              <div class="mb-6">
                <h3 class="font-display text-xl font-bold uppercase text-white tracking-wide">
                  SEND AN INQUIRY
                </h3>
                <p class="text-xs font-mono text-neutral-400 mt-1">
                  Fill in your details and our team will get back to you promptly.
                </p>
              </div>

              @if (isSubmitted()) {
                <div class="p-8 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-4">
                  <div class="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                    <mat-icon class="text-2xl">check</mat-icon>
                  </div>
                  <div class="space-y-1">
                    <h4 class="font-display text-lg font-bold text-white uppercase">Message Sent Successfully</h4>
                    <p class="text-xs font-mono text-neutral-400 max-w-sm mx-auto">
                      Thank you. We have received your note and will contact you via email or WhatsApp shortly.
                    </p>
                  </div>
                  <button
                    type="button"
                    (click)="isSubmitted.set(false); contactForm.reset()"
                    class="px-5 py-2.5 rounded-xl bg-neutral-900 border border-neutral-700 hover:border-white text-xs font-mono text-white uppercase transition-colors cursor-pointer"
                  >
                    Send Another Message
                  </button>
                </div>
              } @else {
                <form [formGroup]="contactForm" (ngSubmit)="submitMessage()" class="space-y-4">
                  
                  <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="space-y-1">
                      <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Your Name *</span>
                      <input
                        type="text"
                        formControlName="name"
                        placeholder="e.g. Ishaan Roy"
                        class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                      />
                    </div>

                    <div class="space-y-1">
                      <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Email Address *</span>
                      <input
                        type="email"
                        formControlName="email"
                        placeholder="e.g. you@example.com"
                        class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  <div class="space-y-1">
                    <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Subject / Purpose</span>
                    <input
                      type="text"
                      formControlName="subject"
                      placeholder="e.g. Sizing Advice for Shadow Eye Acid Wash Hoodie"
                      class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                    />
                  </div>

                  <div class="space-y-1">
                    <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Message *</span>
                    <textarea
                      rows="4"
                      formControlName="message"
                      placeholder="Tell us what you need help with..."
                      class="w-full p-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono leading-relaxed focus:border-red-500 focus:outline-none resize-none"
                    ></textarea>
                  </div>

                  <div class="pt-2">
                    <button
                      type="submit"
                      [disabled]="contactForm.invalid"
                      class="w-full h-12 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-mono text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-red-600/20 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <mat-icon class="text-base">send</mat-icon>
                      <span>SEND MESSAGE TO STYLING DESK</span>
                    </button>
                  </div>

                </form>
              }

            </div>
          </div>

        </div>

      </div>
    </section>
  `,
})
export class ContactComponent {
  readonly store = inject(StoreService);
  private readonly fb = inject(FormBuilder);

  readonly isSubmitted = signal<boolean>(false);

  readonly contactForm = this.fb.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    subject: [''],
    message: ['', [Validators.required, Validators.minLength(5)]],
  });

  submitMessage() {
    if (this.contactForm.invalid) return;
    this.isSubmitted.set(true);
    this.store.showToast('Message sent to styling desk!');
  }
}
