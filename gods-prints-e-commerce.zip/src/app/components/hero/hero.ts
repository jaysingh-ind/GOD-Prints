import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-hero',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <section id="home" class="relative overflow-hidden bg-[#070709] border-b border-white/5 py-20 lg:py-28">
      <!-- Background Ambient Glow & Grid -->
      <div class="absolute inset-0 pointer-events-none">
        <div class="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-red-600/10 blur-[130px] rounded-full"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-red-900/10 blur-[100px] rounded-full"></div>
        <!-- Grid pattern overlay -->
        <div class="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      </div>

      <div class="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          <!-- Left Column: Editorial Hero Copy -->
          <div class="lg:col-span-7 space-y-6 text-center lg:text-left">
            <!-- Brand Kicker / Drop Badge -->
            <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-neutral-900/80 border border-neutral-800 text-xs font-mono tracking-widest text-neutral-300">
              <span class="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              <span>DROP 01 NOW LIVE</span>
              <span class="text-neutral-600">/</span>
              <span class="text-red-400">LIMITED PIECES</span>
            </div>

            <!-- Main Heading: WEAR YOUR POWER. -->
            <h1 class="font-display text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black tracking-tight text-white uppercase leading-[0.95]">
              WEAR <br class="hidden sm:inline" />
              YOUR <br class="hidden sm:inline" />
              <span class="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-500 to-red-700">
                POWER.
              </span>
            </h1>

            <!-- Subtitle: Premium Anime Streetwear -->
            <p class="text-lg sm:text-xl text-neutral-400 font-light max-w-xl mx-auto lg:mx-0">
              Premium Anime Streetwear forged with 420 GSM heavyweight French Terry cotton and bespoke Japanese artisan acid wash.
            </p>

            <!-- Call to Actions -->
            <div class="pt-4 flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
              <!-- Shop Now Button -->
              <a
                href="#shop"
                class="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm tracking-wider uppercase transition-all shadow-xl shadow-red-600/25 active:scale-95 group"
              >
                <span>Shop Now</span>
                <mat-icon class="text-lg group-hover:translate-x-1 transition-transform">arrow_forward</mat-icon>
              </a>

              <!-- Secondary Lookbook / Collection Button -->
              <a
                href="#featured"
                class="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 rounded-xl bg-neutral-900/90 hover:bg-neutral-800 border border-neutral-800 hover:border-neutral-700 text-neutral-200 font-medium text-sm tracking-wider uppercase transition-colors"
              >
                <span>Explore Drop</span>
              </a>
            </div>

            <!-- Trust Markers / Specs Strip -->
            <div class="pt-8 border-t border-white/5 grid grid-cols-3 gap-4 text-center lg:text-left">
              <div>
                <div class="font-display text-2xl font-bold text-white tabular-nums">420 GSM</div>
                <div class="text-xs text-neutral-500 uppercase tracking-wider font-mono">French Terry</div>
              </div>
              <div>
                <div class="font-display text-2xl font-bold text-white">MINERAL</div>
                <div class="text-xs text-neutral-500 uppercase tracking-wider font-mono">Acid Wash</div>
              </div>
              <div>
                <div class="font-display text-2xl font-bold text-red-500">ORIGINAL</div>
                <div class="text-xs text-neutral-500 uppercase tracking-wider font-mono">Tokyo Craft</div>
              </div>
            </div>
          </div>

          <!-- Right Column: Featured Hero Showcase Banner (Preserves proportions) -->
          <div class="lg:col-span-5 relative flex justify-center">
            <div class="relative w-full max-w-md bg-neutral-900/50 rounded-2xl border border-white/10 p-4 shadow-2xl backdrop-blur-sm group">
              <!-- Corner accents -->
              <div class="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-red-500"></div>
              <div class="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-red-500"></div>
              
              <!-- Product Image preview container -->
              <div class="relative aspect-[4/5] w-full rounded-xl overflow-hidden bg-[#0c0c11] border border-white/5 flex items-center justify-center p-3">
                <img
                  [src]="store.activeProduct().frontImage"
                  alt="Shadow Eye Acid Wash Hoodie Front View"
                  class="max-w-full max-h-full w-auto h-auto object-contain select-none img-sharp pointer-events-none"
                  referrerpolicy="no-referrer"
                />

                <!-- Top Floating Tag -->
                <div class="absolute top-3 left-3 px-2.5 py-1 rounded bg-black/80 backdrop-blur-md border border-white/10 text-[11px] font-mono tracking-widest text-neutral-300">
                  SHADOW EYE HOODIE
                </div>

                <!-- Price overlay -->
                <div class="absolute bottom-3 right-3 px-3 py-1.5 rounded-lg bg-red-600/90 backdrop-blur-md text-white font-mono text-xs font-bold shadow-lg">
                  FROM ₹1,499
                </div>
              </div>

              <!-- Quick details caption below hero image -->
              <div class="mt-3 flex items-center justify-between text-xs text-neutral-400 px-1 font-mono">
                <span class="flex items-center gap-1.5 text-neutral-300">
                  <span class="w-1.5 h-1.5 rounded-full bg-red-500"></span>
                  Acid Wash Washed Black
                </span>
                <a href="#shop" class="text-red-400 hover:text-red-300 flex items-center gap-0.5">
                  View Specs
                  <mat-icon class="text-sm">chevron_right</mat-icon>
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  `,
})
export class HeroComponent {
  readonly store = inject(StoreService);
}
