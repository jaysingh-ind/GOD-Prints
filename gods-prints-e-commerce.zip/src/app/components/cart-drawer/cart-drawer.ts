import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';
import { formatCurrencyINR, generateWhatsAppOrderUrl } from '../../utils/store-logic';

@Component({
  selector: 'app-cart-drawer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (store.isCartOpen()) {
      <div class="fixed inset-0 z-50 overflow-hidden">
        <!-- Backdrop Button -->
        <button
          type="button"
          class="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity w-full h-full border-none cursor-default"
          (click)="store.closeCart()"
          aria-label="Close Bag backdrop"
        ></button>

        <!-- Slide-out Drawer Container -->
        <div 
          class="fixed inset-y-0 right-0 w-full max-w-md bg-[#0a0a0e] border-l border-white/10 shadow-2xl flex flex-col z-10"
        >
          
          <!-- Drawer Header -->
          <div class="p-6 border-b border-white/10 flex items-center justify-between shrink-0 bg-[#0e0e13]">
            <div class="flex items-center gap-2">
              <mat-icon class="text-red-500">shopping_bag</mat-icon>
              <h2 class="font-display text-lg font-bold uppercase tracking-wider text-white">
                YOUR BAG
              </h2>
              <span class="text-xs font-mono text-neutral-400">({{ store.cartCount() }} items)</span>
            </div>

            <button
              type="button"
              (click)="store.closeCart()"
              class="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center transition-colors"
              aria-label="Close Bag"
            >
              <mat-icon class="text-base">close</mat-icon>
            </button>
          </div>

          <!-- Free Shipping Progress Tracker -->
          <div class="px-6 py-3.5 bg-neutral-900/60 border-b border-white/5 shrink-0 text-xs font-mono">
            @if (totals().freeShippingQualified) {
              <div class="flex items-center gap-2 text-emerald-400 font-semibold">
                <mat-icon class="text-sm">local_shipping</mat-icon>
                <span>You unlocked FREE Express Delivery across India!</span>
              </div>
            } @else {
              <div class="flex items-center justify-between text-neutral-300 mb-1.5">
                <span>Add {{ formatCurrencyINR(totals().amountNeededForFreeShipping) }} more for FREE delivery</span>
                <span class="text-red-400 font-bold">₹999 goal</span>
              </div>
              <div class="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                <div 
                  class="h-full bg-red-600 rounded-full transition-all duration-300"
                  [style.width.%]="(totals().subtotal / 999) * 100"
                ></div>
              </div>
            }
          </div>

          <!-- Cart Items Scrollable List -->
          <div class="flex-1 overflow-y-auto p-6 space-y-4">
            @if (store.cart().length === 0) {
              <div class="py-20 text-center space-y-4">
                <div class="w-16 h-16 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center mx-auto text-neutral-600">
                  <mat-icon class="text-3xl">shopping_bag</mat-icon>
                </div>
                <div class="space-y-1">
                  <p class="font-display text-base font-bold text-white uppercase">Your bag is empty</p>
                  <p class="text-xs font-mono text-neutral-500">Pick your size and gear up with Drop 01.</p>
                </div>
                <button
                  type="button"
                  (click)="store.closeCart()"
                  class="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-mono font-bold uppercase tracking-wider transition-colors"
                >
                  Explore Collection
                </button>
              </div>
            } @else {
              @for (item of store.cart(); track item.id) {
                <div class="p-4 rounded-xl bg-[#111116] border border-white/5 flex gap-4">
                  <!-- Thumbnail Container -->
                  <div class="w-16 h-20 rounded-lg bg-[#0c0c10] border border-white/5 flex items-center justify-center p-1 shrink-0 overflow-hidden">
                    <img
                      [src]="item.image"
                      [alt]="item.productName"
                      class="w-full h-full object-contain thumbnail-crisp img-sharp"
                      referrerpolicy="no-referrer"
                    />
                  </div>

                  <!-- Details -->
                  <div class="flex-1 min-w-0 space-y-2">
                    <div class="flex items-start justify-between gap-2">
                      <div class="min-w-0">
                        <h4 class="text-xs font-bold text-white truncate font-display">{{ item.productName }}</h4>
                        <div class="flex items-center gap-2 text-[11px] font-mono text-neutral-400 mt-0.5">
                          <span>Size: <strong class="text-red-400">{{ item.size }}</strong></span>
                          <span>·</span>
                          <span>{{ item.color }}</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        (click)="store.removeFromCart(item.id)"
                        class="text-neutral-500 hover:text-red-400 p-1 transition-colors"
                        title="Remove item"
                        aria-label="Remove item"
                      >
                        <mat-icon class="text-base">delete_outline</mat-icon>
                      </button>
                    </div>

                    <!-- Quantity Stepper & Price -->
                    <div class="flex items-center justify-between pt-1">
                      <div class="flex items-center border border-neutral-800 rounded-lg bg-neutral-900 p-0.5">
                        <button
                          type="button"
                          (click)="store.updateCartQuantity(item.id, -1)"
                          class="w-6 h-6 flex items-center justify-center text-neutral-400 hover:text-white rounded hover:bg-neutral-800"
                          aria-label="Decrease quantity"
                        >
                          <mat-icon class="text-xs">remove</mat-icon>
                        </button>
                        <span class="w-7 text-center font-mono text-xs font-bold text-white tabular-nums">
                          {{ item.quantity }}
                        </span>
                        <button
                          type="button"
                          (click)="store.updateCartQuantity(item.id, 1)"
                          class="w-6 h-6 flex items-center justify-center text-neutral-400 hover:text-white rounded hover:bg-neutral-800"
                          aria-label="Increase quantity"
                        >
                          <mat-icon class="text-xs">add</mat-icon>
                        </button>
                      </div>

                      <div class="text-xs font-mono font-bold text-white tabular-nums">
                        {{ formatCurrencyINR(item.unitPrice * item.quantity) }}
                      </div>
                    </div>
                  </div>
                </div>
              }
            }
          </div>

          <!-- Drawer Footer with Totals and Action Buttons -->
          @if (store.cart().length > 0) {
            <div class="p-6 border-t border-white/10 bg-[#0e0e13] space-y-4 shrink-0">
              
              <!-- Subtotal & Shipping breakdown -->
              <div class="space-y-1.5 text-xs font-mono">
                <div class="flex justify-between text-neutral-400">
                  <span>Subtotal:</span>
                  <span class="text-white font-medium tabular-nums">{{ formatCurrencyINR(totals().subtotal) }}</span>
                </div>
                <div class="flex justify-between text-neutral-400">
                  <span>Express Shipping:</span>
                  <span class="tabular-nums" [class.text-emerald-400]="totals().shipping === 0">
                    {{ totals().shipping === 0 ? 'FREE' : formatCurrencyINR(totals().shipping) }}
                  </span>
                </div>
                <div class="flex justify-between text-sm font-bold text-white pt-2 border-t border-white/5">
                  <span class="font-display uppercase tracking-wider">TOTAL DUE:</span>
                  <span class="text-red-500 font-black text-lg tabular-nums">{{ formatCurrencyINR(totals().total) }}</span>
                </div>
              </div>

              <!-- Action Checkout Buttons -->
              <div class="space-y-2.5 pt-1">
                <!-- PREPAID ONLY NOTICE -->
                <div class="p-2.5 rounded-lg bg-red-950/20 border border-red-500/30 text-[10px] font-mono text-center text-red-400 font-bold uppercase">
                  PREPAID ORDERS ONLY · NO CASH ON DELIVERY
                </div>

                <!-- 1. WHATSAPP ORDER BUTTON -->
                <a
                  [href]="whatsAppOrderUrl()"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="w-full h-12 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs font-mono uppercase tracking-wider transition-all flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20 active:scale-95 cursor-pointer"
                >
                  <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24">
                    <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm0 18.09c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.12 8.12 0 01-1.25-4.32c0-4.5 3.66-8.16 8.16-8.16 2.18 0 4.23.85 5.77 2.39a8.106 8.106 0 012.39 5.77c0 4.5-3.66 8.16-8.16 8.16zm4.47-6.1c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.53.06-.25-.13-1.04-.38-1.99-1.22-.73-.65-1.23-1.46-1.37-1.71-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.43.13-.14.17-.25.25-.42.08-.17.04-.31-.02-.44-.06-.13-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.43h-.47c-.17 0-.44.06-.67.31-.23.25-.88.86-.88 2.1s.9 2.43 1.03 2.6c.13.17 1.77 2.7 4.29 3.79.6.26 1.07.41 1.43.53.6.19 1.15.17 1.58.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.15-1.18-.06-.1-.23-.17-.48-.29z"/>
                  </svg>
                  <span>ORDER VIA WHATSAPP (INSTANT CHAT)</span>
                </a>

                <!-- 2. DIRECT PREPAID / ADDRESS CHECKOUT -->
                <button
                  type="button"
                  (click)="store.openCheckout()"
                  class="w-full h-11 rounded-xl bg-white hover:bg-neutral-200 text-black font-bold text-xs font-mono uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <mat-icon class="text-base">local_shipping</mat-icon>
                  <span>ENTER DELIVERY DETAILS</span>
                </button>
              </div>

            </div>
          }

        </div>
      </div>
    }
  `,
})
export class CartDrawerComponent {
  readonly store = inject(StoreService);

  readonly totals = computed(() => this.store.cartTotals());

  readonly whatsAppOrderUrl = computed(() => {
    return generateWhatsAppOrderUrl(this.store.fullWhatsAppNumber(), this.store.cart());
  });

  formatCurrencyINR(val: number) {
    return formatCurrencyINR(val);
  }
}
