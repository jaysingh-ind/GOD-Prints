import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';

@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <header class="sticky top-0 z-40 bg-[#070709]/95 backdrop-blur-md border-b border-white/5 transition-colors">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-6">
        
        <!-- Zone 1: Brand Wordmark -->
        <a href="#home" class="flex items-center gap-2 group whitespace-nowrap shrink-0">
          <div class="w-2.5 h-2.5 rounded-full bg-red-600 group-hover:scale-125 transition-transform"></div>
          <span class="font-display text-2xl font-black tracking-wider text-white uppercase">
            GODS PRINTS
          </span>
          <span class="hidden sm:inline-block text-[10px] tracking-widest text-neutral-400 font-mono pl-1 uppercase border-l border-neutral-800 ml-1">
            神の印
          </span>
        </a>

        <!-- Zone 2: Navigation Links -->
        <nav class="hidden md:flex items-center gap-7 text-xs font-semibold tracking-widest uppercase text-neutral-400">
          <a href="#home" class="hover:text-white transition-colors relative py-1 hover:after:w-full after:w-0 after:h-[1.5px] after:bg-red-600 after:absolute after:bottom-0 after:left-0 after:transition-all">
            Home
          </a>
          <a href="#shop" class="hover:text-white transition-colors relative py-1 hover:after:w-full after:w-0 after:h-[1.5px] after:bg-red-600 after:absolute after:bottom-0 after:left-0 after:transition-all">
            Shop
          </a>
          <a href="#featured" class="hover:text-white transition-colors relative py-1 hover:after:w-full after:w-0 after:h-[1.5px] after:bg-red-600 after:absolute after:bottom-0 after:left-0 after:transition-all">
            Collection
          </a>
          <button
            type="button"
            (click)="store.openReturnModal()"
            class="hover:text-white transition-colors relative py-1 uppercase tracking-widest cursor-pointer text-left"
          >
            Returns (24h)
          </button>
          <a href="#about" class="hover:text-white transition-colors relative py-1 hover:after:w-full after:w-0 after:h-[1.5px] after:bg-red-600 after:absolute after:bottom-0 after:left-0 after:transition-all">
            About
          </a>
          <a href="#contact" class="hover:text-white transition-colors relative py-1 hover:after:w-full after:w-0 after:h-[1.5px] after:bg-red-600 after:absolute after:bottom-0 after:left-0 after:transition-all">
            Contact
          </a>
        </nav>

        <!-- Zone 3: Actions (Cart & Admin Portal) -->
        <div class="flex items-center gap-3 shrink-0">
          <!-- Admin Portal Button -->
          <button
            type="button"
            (click)="store.openAdmin()"
            class="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-800 hover:border-neutral-700 bg-neutral-900/60 hover:bg-neutral-800 text-neutral-300 hover:text-white text-xs font-medium transition-colors cursor-pointer"
            title="Open Admin Product Management Studio"
          >
            <mat-icon class="text-base leading-none text-red-500">
              {{ store.isAdminAuthenticated() ? 'tune' : 'lock' }}
            </mat-icon>
            <span class="hidden sm:inline">Admin</span>
          </button>

          <!-- Shopping Cart Button -->
          <button
            type="button"
            (click)="store.openCart()"
            class="relative flex items-center justify-center w-11 h-11 rounded-lg border border-white/10 bg-neutral-900/80 hover:bg-neutral-800 hover:border-white/20 text-white transition-colors cursor-pointer"
            aria-label="View Shopping Cart"
          >
            <mat-icon class="text-xl">shopping_bag</mat-icon>
            @if (store.cartCount() > 0) {
              <span class="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1 rounded-full bg-red-600 text-white text-[11px] font-bold flex items-center justify-center shadow-lg shadow-red-600/30 tabular-nums">
                {{ store.cartCount() }}
              </span>
            }
          </button>

          <!-- Mobile Hamburger Toggle -->
          <button
            type="button"
            (click)="mobileMenuOpen.set(!mobileMenuOpen())"
            class="md:hidden flex items-center justify-center w-11 h-11 rounded-lg border border-white/10 bg-neutral-900/80 text-white hover:bg-neutral-800 cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            <mat-icon>{{ mobileMenuOpen() ? 'close' : 'menu' }}</mat-icon>
          </button>
        </div>
      </div>

      <!-- Mobile Dropdown Menu -->
      @if (mobileMenuOpen()) {
        <div class="md:hidden border-b border-neutral-800 bg-[#0d0d12] px-6 py-6 space-y-4">
          <nav class="flex flex-col space-y-4 text-sm font-semibold tracking-wider uppercase text-neutral-300">
            <a href="#home" (click)="mobileMenuOpen.set(false)" class="hover:text-red-500 transition-colors py-1">Home</a>
            <a href="#shop" (click)="mobileMenuOpen.set(false)" class="hover:text-red-500 transition-colors py-1">Shop</a>
            <a href="#featured" (click)="mobileMenuOpen.set(false)" class="hover:text-red-500 transition-colors py-1">Collection</a>
            <button
              type="button"
              (click)="store.openReturnModal(); mobileMenuOpen.set(false)"
              class="text-left hover:text-red-500 transition-colors py-1 uppercase font-semibold text-neutral-300"
            >
              24h Returns &amp; Exchange
            </button>
            <a href="#about" (click)="mobileMenuOpen.set(false)" class="hover:text-red-500 transition-colors py-1">About Us</a>
            <a href="#contact" (click)="mobileMenuOpen.set(false)" class="hover:text-red-500 transition-colors py-1">Contact</a>
          </nav>
          
          <div class="pt-4 border-t border-neutral-800 flex items-center justify-between">
            <button
              type="button"
              (click)="store.openAdmin(); mobileMenuOpen.set(false)"
              class="flex items-center gap-2 text-xs text-neutral-400 hover:text-white"
            >
              <mat-icon class="text-sm text-red-500">tune</mat-icon>
              <span>Admin Studio &amp; Uploads</span>
            </button>
            <div class="text-[11px] font-mono text-neutral-500">PREPAID ONLY · NO COD</div>
          </div>
        </div>
      }
    </header>
  `,
})
export class HeaderComponent {
  readonly store = inject(StoreService);
  readonly mobileMenuOpen = signal<boolean>(false);
}
