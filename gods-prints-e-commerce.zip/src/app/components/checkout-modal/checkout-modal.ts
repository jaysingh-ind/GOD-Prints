import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';
import { OrderCustomerDetails } from '../../models/product.model';
import { formatCurrencyINR } from '../../utils/store-logic';

@Component({
  selector: 'app-checkout-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.isCheckoutOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 overflow-y-auto">
        <!-- Backdrop Button -->
        <button
          type="button"
          class="fixed inset-0 bg-black/85 backdrop-blur-md cursor-default border-none w-full h-full"
          (click)="store.closeCheckout()"
          aria-label="Close checkout modal"
        ></button>

        <div 
          class="relative w-full max-w-lg bg-[#0d0d12] border border-white/10 rounded-2xl shadow-2xl overflow-hidden my-8 z-10"
        >
          
          <!-- Header -->
          <div class="px-6 py-4 bg-[#121219] border-b border-white/10 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="text-red-500">local_shipping</mat-icon>
              <h3 class="font-display text-base font-bold text-white uppercase tracking-wider">
                {{ confirmedOrder() ? 'ORDER SUMMARY & PAYMENT' : 'EXPRESS CHECKOUT' }}
              </h3>
            </div>
            <button
              type="button"
              (click)="store.closeCheckout()"
              class="w-8 h-8 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white flex items-center justify-center"
              aria-label="Close"
            >
              <mat-icon class="text-sm">close</mat-icon>
            </button>
          </div>

          <!-- Body -->
          <div class="p-6">
            @if (confirmedOrder()) {
              <!-- Order Request Generated State (Does NOT pretend order is confirmed until paid!) -->
              <div class="text-center space-y-5 py-2">
                <div class="w-16 h-16 rounded-full bg-yellow-500/10 border border-yellow-500/30 flex items-center justify-center mx-auto text-yellow-400">
                  <mat-icon class="text-3xl">hourglass_top</mat-icon>
                </div>

                <div class="space-y-1">
                  <div class="text-xs font-mono text-yellow-400 uppercase tracking-widest font-bold">
                    ORDER REQUEST SUBMITTED · AWAITING PAYMENT
                  </div>
                  <h4 class="font-display text-2xl font-black text-white">#{{ orderId() }}</h4>
                  <p class="text-xs font-mono text-neutral-400 max-w-sm mx-auto leading-relaxed">
                    Thank you, {{ confirmedOrder()?.fullName }}. Your order is reserved. Tap below to send this receipt to WhatsApp to complete payment via UPI.
                  </p>
                </div>

                <!-- Payment Instructions Card -->
                <div class="p-4 rounded-xl bg-neutral-900/80 border border-white/10 text-left text-xs font-mono space-y-2.5">
                  <div class="flex items-center gap-2 text-red-400 font-bold uppercase tracking-wider text-[11px] border-b border-white/5 pb-2">
                    <mat-icon class="text-sm">error_outline</mat-icon>
                    <span>PREPAID ORDERS ONLY · NO CASH ON DELIVERY</span>
                  </div>
                  <p class="text-neutral-300 leading-relaxed text-[11px]">
                    {{ store.settings().paymentInstructions }}
                  </p>
                  @if (store.settings().paymentUpiId) {
                    <div class="p-2.5 rounded-lg bg-black/60 border border-white/5 flex items-center justify-between">
                      <span class="text-neutral-400">Official UPI ID:</span>
                      <span class="text-emerald-400 font-bold select-all">{{ store.settings().paymentUpiId }}</span>
                    </div>
                  }
                  <div class="flex justify-between text-neutral-400 pt-1">
                    <span>Delivery Address:</span>
                    <span class="text-white text-right max-w-[210px] truncate">
                      {{ confirmedOrder()?.address }}, {{ confirmedOrder()?.city }} ({{ confirmedOrder()?.pincode }})
                    </span>
                  </div>
                  <div class="flex justify-between text-neutral-400 pt-2 border-t border-white/5">
                    <span>Total Amount Payable:</span>
                    <span class="text-red-400 font-bold text-base">{{ formattedConfirmedTotal() }}</span>
                  </div>
                </div>

                <!-- WhatsApp Order Forwarding Button -->
                <div class="space-y-2 pt-2">
                  <a
                    [href]="whatsAppOrderUrl()"
                    target="_blank"
                    rel="noopener noreferrer"
                    class="w-full h-12 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-lg shadow-[#25D366]/20"
                  >
                    <span>SEND ORDER &amp; PAY VIA WHATSAPP</span>
                    <mat-icon class="text-sm">arrow_forward</mat-icon>
                  </a>

                  <button
                    type="button"
                    (click)="store.closeCheckout(); store.clearCart(); confirmedOrder.set(null)"
                    class="w-full h-10 rounded-xl bg-neutral-900 text-neutral-300 hover:text-white text-xs font-mono uppercase tracking-wider transition-colors"
                  >
                    Done · Return to Storefront
                  </button>
                </div>
              </div>

            } @else {
              <!-- Customer Details Form -->
              <form [formGroup]="checkoutForm" (ngSubmit)="submitOrder()" class="space-y-4">
                
                <!-- Explicit NO COD / PREPAID Notice Banner -->
                <div class="p-3.5 rounded-xl bg-red-950/20 border border-red-500/30 flex items-center gap-3">
                  <mat-icon class="text-red-500 text-lg shrink-0">verified_user</mat-icon>
                  <div class="text-[11px] font-mono leading-tight">
                    <span class="text-red-400 font-bold uppercase block">
                      {{ store.settings().paymentNotice }}
                    </span>
                    <span class="text-neutral-400">
                      Orders are processed immediately once payment is confirmed via UPI. No account needed.
                    </span>
                  </div>
                </div>

                <!-- Order Summary Chip -->
                <div class="p-3.5 rounded-xl bg-neutral-900/80 border border-white/5 flex items-center justify-between text-xs font-mono">
                  <span class="text-neutral-400">{{ store.cartCount() }} items in Bag</span>
                  <span class="text-white font-bold">Total: {{ formattedTotal() }}</span>
                </div>

                <!-- Full Name -->
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Full Name *</span>
                  <input
                    type="text"
                    formControlName="fullName"
                    placeholder="e.g. Rahul Sharma"
                    class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                  />
                </div>

                <!-- WhatsApp / Contact Phone -->
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">WhatsApp / Phone Number *</span>
                  <input
                    type="tel"
                    formControlName="phone"
                    placeholder="e.g. 9876543210"
                    class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                  />
                  <span class="text-[10px] text-neutral-500 font-mono">For instant order tracking and delivery updates</span>
                </div>

                <!-- Address -->
                <div class="space-y-1">
                  <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Delivery Street Address *</span>
                  <input
                    type="text"
                    formControlName="address"
                    placeholder="Flat / Building / Street address"
                    class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                  />
                </div>

                <!-- City & Pincode -->
                <div class="grid grid-cols-2 gap-3">
                  <div class="space-y-1">
                    <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">City *</span>
                    <input
                      type="text"
                      formControlName="city"
                      placeholder="e.g. Bengaluru"
                      class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                    />
                  </div>
                  <div class="space-y-1">
                    <span class="block text-xs font-mono uppercase text-neutral-300 font-semibold">Pincode *</span>
                    <input
                      type="text"
                      formControlName="pincode"
                      placeholder="e.g. 560001"
                      class="w-full h-11 px-3.5 rounded-xl bg-neutral-900 border border-neutral-800 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                    />
                  </div>
                </div>

                <!-- Payment Selection: Guaranteed Prepaid Only -->
                <div class="p-3.5 rounded-xl bg-[#08080b] border border-white/10 space-y-2">
                  <div class="flex items-center justify-between text-xs font-mono">
                    <span class="font-bold text-white flex items-center gap-1.5">
                      <mat-icon class="text-sm text-emerald-400">lock</mat-icon>
                      Payment Mode: Prepaid Direct UPI
                    </span>
                    <span class="text-emerald-400 font-bold text-[10px]">VERIFIED</span>
                  </div>
                  <p class="text-[11px] text-neutral-400 font-mono leading-relaxed">
                    UPI QR and payment handles will be shared directly on our official WhatsApp line ({{ store.displayWhatsAppNumber() }}).
                  </p>
                </div>

                <!-- Submit Button -->
                <div class="pt-2">
                  <button
                    type="submit"
                    [disabled]="checkoutForm.invalid"
                    class="w-full h-12 rounded-xl bg-red-600 hover:bg-red-500 disabled:opacity-40 text-white font-mono text-xs font-bold uppercase tracking-wider transition-all shadow-xl shadow-red-600/20 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <mat-icon class="text-base">check</mat-icon>
                    <span>REVIEW &amp; PLACE ORDER · {{ formattedTotal() }}</span>
                  </button>
                </div>

              </form>
            }
          </div>

        </div>
      </div>
    }
  `,
})
export class CheckoutModalComponent {
  readonly store = inject(StoreService);
  private readonly fb = inject(FormBuilder);

  readonly confirmedOrder = signal<OrderCustomerDetails | null>(null);
  readonly orderId = signal<string>('GP-10001');
  readonly whatsAppOrderUrl = signal<string>('');
  readonly savedTotal = signal<number>(0);

  readonly checkoutForm = this.fb.group({
    fullName: ['', Validators.required],
    phone: ['', [Validators.required, Validators.minLength(10)]],
    address: ['', Validators.required],
    city: ['', Validators.required],
    pincode: ['', [Validators.required, Validators.minLength(5)]],
  });

  readonly formattedTotal = computed(() => {
    return formatCurrencyINR(this.store.cartTotals().total);
  });

  readonly formattedConfirmedTotal = computed(() => {
    return formatCurrencyINR(this.savedTotal());
  });

  async submitOrder() {
    if (this.checkoutForm.invalid) return;

    const val = this.checkoutForm.value;
    const customer: OrderCustomerDetails = {
      fullName: val.fullName || '',
      phone: val.phone || '',
      address: val.address || '',
      city: val.city || '',
      pincode: val.pincode || '',
      paymentMethod: 'prepaid_upi',
    };

    this.savedTotal.set(this.store.cartTotals().total);

    const { orderId, whatsAppUrl } = await this.store.submitOrder(customer);
    this.orderId.set(orderId);
    this.whatsAppOrderUrl.set(whatsAppUrl);
    this.confirmedOrder.set(customer);
  }
}
