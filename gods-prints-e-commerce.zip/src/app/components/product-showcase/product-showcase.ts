import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from '../../services/store.service';
import { formatCurrencyINR, generateWhatsAppOrderUrl } from '../../utils/store-logic';

@Component({
  selector: 'app-product-showcase',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <section id="shop" class="relative py-16 lg:py-24 bg-[#09090d] border-b border-white/5 scroll-mt-20">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Section Header -->
        <div class="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-white/10 pb-6">
          <div>
            <div class="text-xs font-mono uppercase tracking-widest text-red-500 mb-2 flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-red-600"></span>
              HEADLINER PIECE // ARCHIVE 01
            </div>
            <h2 class="font-display text-3xl sm:text-4xl lg:text-5xl font-black uppercase text-white tracking-tight">
              {{ product().name }}
            </h2>
          </div>

          <div class="flex items-center gap-3">
            <!-- Admin Upload Images Shortcut -->
            <button
              type="button"
              (click)="store.openAdmin()"
              class="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-neutral-900 border border-neutral-700 hover:border-red-500/50 text-neutral-300 hover:text-white text-xs font-mono transition-colors"
              title="Open Admin to upload Front and Back photos from your computer"
            >
              <mat-icon class="text-base text-red-500">cloud_upload</mat-icon>
              <span>Upload Custom Images</span>
            </button>

            <!-- Size Guide Trigger -->
            <button
              type="button"
              (click)="store.openSizeGuide()"
              class="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-neutral-900/60 border border-neutral-800 text-neutral-400 hover:text-white text-xs font-medium transition-colors"
            >
              <mat-icon class="text-base">straighten</mat-icon>
              <span>Size Chart</span>
            </button>
          </div>
        </div>

        <!-- Main Product Layout Grid -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14">
          
          <!-- ========================================= -->
          <!-- LEFT: PRODUCT GALLERY (FRONT & BACK VIEW) -->
          <!-- ========================================= -->
          <div class="lg:col-span-7 space-y-4">
            
            <!-- Gallery View Switcher Tabs (FRONT VIEW vs BACK VIEW) -->
            <div class="flex items-center justify-between bg-[#111116] p-1.5 rounded-xl border border-white/10">
              <div class="flex items-center gap-2">
                <!-- Front View Tab -->
                <button
                  type="button"
                  (click)="store.setGalleryView('front')"
                  [class]="store.activeGalleryView() === 'front' 
                    ? 'bg-neutral-800 text-white shadow-md border-red-500/30' 
                    : 'text-neutral-400 hover:text-neutral-200'"
                  class="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono uppercase tracking-wider font-bold transition-all border border-transparent"
                >
                  <mat-icon class="text-sm">visibility</mat-icon>
                  <span>FRONT VIEW</span>
                  @if (product().frontUploaded) {
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Custom Uploaded"></span>
                  }
                </button>

                <!-- Back View Tab -->
                <button
                  type="button"
                  (click)="store.setGalleryView('back')"
                  [class]="store.activeGalleryView() === 'back' 
                    ? 'bg-neutral-800 text-white shadow-md border-red-500/30' 
                    : 'text-neutral-400 hover:text-neutral-200'"
                  class="flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono uppercase tracking-wider font-bold transition-all border border-transparent"
                >
                  <mat-icon class="text-sm">flip</mat-icon>
                  <span>BACK VIEW</span>
                  @if (product().backUploaded) {
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400" title="Custom Uploaded"></span>
                  }
                </button>
              </div>

              <!-- Zoom & Fullscreen Action -->
              <button
                type="button"
                (click)="store.openZoom()"
                class="flex items-center gap-1 px-3 py-1.5 text-xs text-neutral-400 hover:text-white rounded hover:bg-neutral-800/80 transition-colors"
                title="Zoom view"
                aria-label="Zoom image"
              >
                <mat-icon class="text-base">zoom_in</mat-icon>
                <span class="hidden sm:inline">Zoom</span>
              </button>
            </div>

            <!-- Main Interactive Display Viewport (Preserves exact image proportions & full resolution) -->
            <button
              type="button"
              class="relative w-full aspect-[4/5] sm:aspect-[1/1] lg:aspect-[4/5] bg-[#0c0c11] rounded-2xl border border-white/10 hover:border-red-500/30 hover:shadow-2xl hover:shadow-red-600/10 transition-all overflow-hidden flex items-center justify-center p-3 sm:p-5 group cursor-zoom-in text-left focus:outline-none focus:ring-2 focus:ring-red-500"
              (click)="store.openZoom()"
              aria-label="Open image in fullscreen zoom"
            >
              <!-- Ambient Studio Light Behind Image -->
              <div class="absolute inset-0 bg-gradient-to-b from-white/[0.03] to-transparent pointer-events-none"></div>

              <!-- Active View Image (Preserves Original Proportions via object-contain & img-sharp) -->
              <img
                [src]="currentDisplayImage()"
                [alt]="product().name + ' ' + (store.activeGalleryView() === 'front' ? 'Front View' : 'Back View')"
                class="max-w-full max-h-full w-auto h-auto object-contain select-none img-sharp pointer-events-none"
                referrerpolicy="no-referrer"
              />

              <!-- Active View Badge -->
              <div class="absolute top-4 left-4 px-3 py-1.5 rounded-md bg-black/85 backdrop-blur-md border border-white/15 text-[11px] font-mono tracking-widest text-neutral-200 flex items-center gap-2">
                <span class="w-2 h-2 rounded-full" [class]="store.activeGalleryView() === 'front' ? 'bg-red-500' : 'bg-red-600'"></span>
                <span>{{ store.activeGalleryView() === 'front' ? 'FRONT VIEW' : 'BACK VIEW' }}</span>
                @if (isCurrentImageUploaded()) {
                  <span class="text-emerald-400 font-bold text-[10px] uppercase border-l border-neutral-700 pl-1.5">CUSTOM UPLOAD</span>
                }
              </div>

              <!-- Quick Replace / Admin Hint in Gallery -->
              <div class="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                <span class="text-[11px] font-mono text-neutral-300 bg-black/85 px-2.5 py-1 rounded-md backdrop-blur-md border border-white/15 flex items-center gap-1.5">
                  <mat-icon class="text-sm text-red-500">zoom_in</mat-icon>
                  Click to inspect full resolution
                </span>
                <span class="text-[11px] font-mono text-red-400 bg-black/85 px-2.5 py-1 rounded-md backdrop-blur-md border border-white/15">
                  Deep Zoom &amp; Pan →
                </span>
              </div>
            </button>

            <!-- Two Dual Thumbnail Preview Cards -->
            <div class="grid grid-cols-2 gap-4">
              <!-- Front View Thumbnail Card -->
              <button
                type="button"
                (click)="store.setGalleryView('front')"
                [class]="store.activeGalleryView() === 'front' ? 'border-red-600 bg-neutral-900/95 shadow-md shadow-red-600/10' : 'border-neutral-800 bg-[#0c0c10] hover:border-neutral-700'"
                class="cursor-pointer p-3 rounded-xl border transition-all flex items-center gap-3 text-left focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-[#08080c] overflow-hidden flex items-center justify-center border border-white/10 shrink-0 p-1">
                  <img
                    [src]="product().frontImage"
                    alt="Front thumbnail"
                    class="w-full h-full object-contain thumbnail-crisp img-sharp"
                    referrerpolicy="no-referrer"
                  />
                </div>
                <div class="min-w-0 flex-1">
                  <div class="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                    <span>FRONT VIEW</span>
                    @if (product().frontUploaded) {
                      <mat-icon class="text-xs text-emerald-400">check_circle</mat-icon>
                    }
                  </div>
                  <div class="text-[11px] text-neutral-400 font-mono truncate">Chest Seal &amp; Fit</div>
                  <div class="text-[10px] text-neutral-500 font-mono mt-0.5">High-Res Original</div>
                </div>
              </button>

              <!-- Back View Thumbnail Card -->
              <button
                type="button"
                (click)="store.setGalleryView('back')"
                [class]="store.activeGalleryView() === 'back' ? 'border-red-600 bg-neutral-900/95 shadow-md shadow-red-600/10' : 'border-neutral-800 bg-[#0c0c10] hover:border-neutral-700'"
                class="cursor-pointer p-3 rounded-xl border transition-all flex items-center gap-3 text-left focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <div class="w-16 h-16 sm:w-20 sm:h-20 rounded-xl bg-[#08080c] overflow-hidden flex items-center justify-center border border-white/10 shrink-0 p-1">
                  <img
                    [src]="product().backImage"
                    alt="Back thumbnail"
                    class="w-full h-full object-contain thumbnail-crisp img-sharp"
                    referrerpolicy="no-referrer"
                  />
                </div>
                <div class="min-w-0 flex-1">
                  <div class="text-xs font-mono font-bold text-white flex items-center gap-1.5">
                    <span>BACK VIEW</span>
                    @if (product().backUploaded) {
                      <mat-icon class="text-xs text-emerald-400">check_circle</mat-icon>
                    }
                  </div>
                  <div class="text-[11px] text-neutral-400 font-mono truncate">Full Back Art</div>
                  <div class="text-[10px] text-neutral-500 font-mono mt-0.5">High-Res Original</div>
                </div>
              </button>
            </div>

          </div>

          <!-- ========================================= -->
          <!-- RIGHT: CONTIGUOUS PURCHASE & SPECS MODULE -->
          <!-- ========================================= -->
          <div class="lg:col-span-5 space-y-6">
            
            <!-- Product Identity & Dynamic Price Section -->
            <div class="bg-[#101015] rounded-2xl border border-white/10 p-6 space-y-6">
              
              <div>
                <div class="flex items-center justify-between text-xs font-mono text-neutral-400 mb-2">
                  <span>ITEM CODE: GP-{{ product().id.substring(0, 8).toUpperCase() }}</span>
                  <span class="text-emerald-400 font-semibold flex items-center gap-1">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    READY TO SHIP
                  </span>
                </div>
                <h1 class="font-display text-2xl sm:text-3xl font-extrabold text-white">
                  {{ product().name }}
                </h1>
                <p class="text-xs font-mono text-neutral-400 mt-1">
                  Color: <span class="text-white font-medium">{{ product().color }} (Acid Wash Finish)</span>
                </p>
              </div>

              <!-- Available Pieces Selector (When multiple pieces are live) -->
              @if (store.publishedProducts().length > 1) {
                <div class="space-y-2 pb-2">
                  <span class="text-[11px] font-mono text-neutral-400 uppercase tracking-wider block">AVAILABLE PIECES IN DROP:</span>
                  <div class="flex flex-wrap gap-2">
                    @for (item of store.publishedProducts(); track item.id) {
                      <button
                        type="button"
                        (click)="store.selectProduct(item.id)"
                        [class]="item.id === product().id ? 'bg-red-600 text-white font-bold border-red-500 shadow-md shadow-red-600/30' : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-neutral-600'"
                        class="px-3 py-1.5 rounded-lg border text-xs font-mono transition-colors cursor-pointer"
                      >
                        {{ item.name }}
                      </button>
                    }
                  </div>
                </div>
              }

              <!-- DYNAMIC PRICE DISPLAY (₹1,499 for XS-XXL, ₹1,599 for 3XL) -->
              <div class="p-4 rounded-xl bg-black/60 border border-white/10 space-y-2">
                <div class="flex items-baseline gap-3">
                  <span class="font-display text-4xl sm:text-5xl font-black text-white tabular-nums tracking-tight">
                    {{ formattedPrice() }}
                  </span>
                  <span class="text-xs font-mono text-neutral-400">Inclusive of all taxes</span>
                </div>

                <!-- Clear Pricing Rule Explanation -->
                <div class="pt-2 border-t border-white/5 flex items-center justify-between text-xs font-mono">
                  <span class="text-neutral-400">Size Tier Pricing:</span>
                  <span class="text-neutral-200">
                    <span [class.text-red-400]="store.selectedSize() !== '3XL'" [class.font-bold]="store.selectedSize() !== '3XL'">₹{{ product().basePrice }} (XS–XXL)</span>
                    <span class="text-neutral-600 mx-1">·</span>
                    <span [class.text-red-400]="store.selectedSize() === '3XL'" [class.font-bold]="store.selectedSize() === '3XL'">₹{{ product().price3XL }} (3XL)</span>
                  </span>
                </div>

                @if (store.selectedSize() === '3XL') {
                  <div class="text-[11px] font-mono text-amber-400/90 flex items-center gap-1 pt-1">
                    <mat-icon class="text-sm">info</mat-icon>
                    <span>3XL heavy fabric surcharge applied (+₹100)</span>
                  </div>
                }
              </div>

              <!-- WORKING SIZE SELECTOR -->
              <div class="space-y-3">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-mono uppercase tracking-wider text-neutral-300 font-bold flex items-center gap-2">
                    <span>SELECT SIZE:</span>
                    <span class="text-red-400 font-extrabold">{{ store.selectedSize() }}</span>
                  </span>
                  <button
                    type="button"
                    (click)="store.openSizeGuide()"
                    class="text-xs text-neutral-400 hover:text-white underline decoration-neutral-700 underline-offset-4 font-mono transition-colors"
                  >
                    Size Guide (Chest/Length)
                  </button>
                </div>

                <!-- Sizes Pill/Button Grid -->
                <div class="grid grid-cols-4 sm:grid-cols-7 gap-2">
                  @for (size of product().sizes; track size) {
                    <button
                      type="button"
                      (click)="store.setSize(size)"
                      [class]="store.selectedSize() === size 
                        ? 'bg-red-600 text-white border-red-500 shadow-lg shadow-red-600/30 scale-105' 
                        : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-neutral-600 hover:text-white'"
                      class="h-12 rounded-xl border text-xs font-mono font-bold tracking-wider transition-all flex flex-col items-center justify-center relative active:scale-95"
                    >
                      <span>{{ size }}</span>
                      <span class="text-[9px] opacity-75 font-normal">
                        {{ size === '3XL' ? '₹1,599' : '₹1,499' }}
                      </span>
                    </button>
                  }
                </div>
              </div>

              <!-- QUANTITY SELECTOR -->
              <div class="space-y-2">
                <span class="block text-xs font-mono uppercase tracking-wider text-neutral-400">QUANTITY</span>
                <div class="flex items-center gap-4">
                  <div class="flex items-center border border-neutral-800 rounded-xl bg-neutral-900 p-1">
                    <button
                      type="button"
                      (click)="store.decrementQuantity()"
                      [disabled]="store.quantity() <= 1"
                      class="w-10 h-10 flex items-center justify-center text-neutral-300 hover:text-white disabled:opacity-30 rounded-lg hover:bg-neutral-800 transition-colors"
                      aria-label="Decrease quantity"
                    >
                      <mat-icon class="text-lg">remove</mat-icon>
                    </button>
                    <span class="w-12 text-center font-mono font-bold text-white tabular-nums">
                      {{ store.quantity() }}
                    </span>
                    <button
                      type="button"
                      (click)="store.incrementQuantity()"
                      [disabled]="store.quantity() >= 10"
                      class="w-10 h-10 flex items-center justify-center text-neutral-300 hover:text-white disabled:opacity-30 rounded-lg hover:bg-neutral-800 transition-colors"
                      aria-label="Increase quantity"
                    >
                      <mat-icon class="text-lg">add</mat-icon>
                    </button>
                  </div>
                  <div class="text-xs font-mono text-neutral-400">
                    Total for {{ store.quantity() }} pc: <span class="text-white font-bold">{{ formattedCurrentBatchTotal() }}</span>
                  </div>
                </div>
              </div>

              <!-- PREPAID ONLY NOTICE -->
              <div class="p-3 rounded-xl bg-red-950/20 border border-red-500/30 flex items-center gap-2.5">
                <mat-icon class="text-red-500 text-base shrink-0">verified_user</mat-icon>
                <div class="text-[11px] font-mono leading-tight">
                  <span class="text-red-400 font-bold uppercase block">{{ store.settings().paymentNotice }}</span>
                  <span class="text-neutral-400">Orders are reserved and dispatched upon UPI / Net Banking confirmation.</span>
                </div>
              </div>

              <!-- CONTIGUOUS PRIMARY ACTION BUTTONS -->
              <div class="space-y-3 pt-1">
                
                <!-- 1. ADD TO BAG -->
                <button
                  type="button"
                  (click)="store.addToCart()"
                  class="w-full h-14 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-sm tracking-wider uppercase transition-all shadow-xl shadow-red-600/20 active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <mat-icon class="text-lg">shopping_bag</mat-icon>
                  <span>ADD TO BAG · {{ formattedCurrentBatchTotal() }}</span>
                </button>

                <!-- 2. BUY NOW (Instant Express Checkout) -->
                <button
                  type="button"
                  (click)="handleBuyNow()"
                  class="w-full h-12 rounded-xl bg-white hover:bg-neutral-200 text-black font-bold text-xs tracking-wider uppercase transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
                >
                  <mat-icon class="text-lg">flash_on</mat-icon>
                  <span>BUY NOW (EXPRESS CHECKOUT)</span>
                </button>

                <!-- 3. DIRECT WHATSAPP ORDER BUTTON -->
                <a
                  [href]="directWhatsAppUrl()"
                  target="_blank"
                  rel="noopener noreferrer"
                  class="w-full h-12 rounded-xl bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-xs tracking-wider uppercase transition-all active:scale-[0.98] flex items-center justify-center gap-2 shadow-lg shadow-[#25D366]/20 cursor-pointer"
                >
                  <!-- WhatsApp SVG Icon -->
                  <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm0 18.09c-1.48 0-2.93-.4-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.12 8.12 0 01-1.25-4.32c0-4.5 3.66-8.16 8.16-8.16 2.18 0 4.23.85 5.77 2.39a8.106 8.106 0 012.39 5.77c0 4.5-3.66 8.16-8.16 8.16zm4.47-6.1c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.53.06-.25-.13-1.04-.38-1.99-1.22-.73-.65-1.23-1.46-1.37-1.71-.14-.25-.01-.38.11-.5.11-.11.25-.29.37-.43.13-.14.17-.25.25-.42.08-.17.04-.31-.02-.44-.06-.13-.56-1.34-.76-1.84-.2-.48-.4-.42-.56-.43h-.47c-.17 0-.44.06-.67.31-.23.25-.88.86-.88 2.1s.9 2.43 1.03 2.6c.13.17 1.77 2.7 4.29 3.79.6.26 1.07.41 1.43.53.6.19 1.15.17 1.58.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.15-1.18-.06-.1-.23-.17-.48-.29z"/>
                  </svg>
                  <span>ORDER VIA WHATSAPP (INSTANT CHAT)</span>
                </a>
              </div>

              <!-- Shipping & 24h Guarantee Badges -->
              <div class="pt-4 border-t border-white/5 space-y-2.5 text-xs font-mono text-neutral-400">
                <div class="flex items-center gap-2">
                  <mat-icon class="text-sm text-red-500">local_shipping</mat-icon>
                  <span>Free Insured Express Delivery across India on orders above ₹999</span>
                </div>
                <button
                  type="button"
                  (click)="store.openReturnModal()"
                  class="flex items-center gap-2 hover:text-white transition-colors cursor-pointer text-left w-full group"
                >
                  <mat-icon class="text-sm text-yellow-500">assignment_return</mat-icon>
                  <span class="text-yellow-400 font-bold group-hover:underline">24-Hour Return Window</span>
                  <span>· Transit damage / verified issues (Tap for policy &amp; claims)</span>
                </button>
                <div class="flex items-center gap-2">
                  <mat-icon class="text-sm text-red-500">verified</mat-icon>
                  <span>100% Authentic Heavyweight Combed Cotton ({{ product().gsm }} GSM)</span>
                </div>
              </div>

            </div>

            <!-- Product Specs & Accordion Tabs -->
            <div class="bg-[#101015] rounded-2xl border border-white/10 p-6 space-y-4">
              <h3 class="text-xs font-mono uppercase tracking-widest text-neutral-400 font-bold border-b border-white/10 pb-3">
                PRODUCT SPECIFICATIONS
              </h3>

              <div class="space-y-3 text-xs">
                <div class="flex justify-between py-1.5 border-b border-white/5 font-mono">
                  <span class="text-neutral-500">Fabric Composition:</span>
                  <span class="text-neutral-200">{{ product().fabric }}</span>
                </div>
                <div class="flex justify-between py-1.5 border-b border-white/5 font-mono">
                  <span class="text-neutral-500">Fabric Weight:</span>
                  <span class="text-neutral-200">{{ product().gsm }} GSM Ultra-Heavyweight</span>
                </div>
                <div class="flex justify-between py-1.5 border-b border-white/5 font-mono">
                  <span class="text-neutral-500">Cut &amp; Fit:</span>
                  <span class="text-neutral-200">{{ product().fit }}</span>
                </div>
                <div class="flex justify-between py-1.5 border-b border-white/5 font-mono">
                  <span class="text-neutral-500">Color / Wash:</span>
                  <span class="text-neutral-200">{{ product().color }}</span>
                </div>
                <div class="flex justify-between py-1.5 font-mono">
                  <span class="text-neutral-500">Category:</span>
                  <span class="text-neutral-200">{{ product().category }}</span>
                </div>
              </div>

              <!-- Craft Description Paragraph -->
              <p class="text-xs text-neutral-400 leading-relaxed pt-2 border-t border-white/5">
                {{ product().description }}
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  `,
})
export class ProductShowcaseComponent {
  readonly store = inject(StoreService);

  readonly product = computed(() => this.store.activeProduct());

  readonly formattedPrice = computed(() => {
    return formatCurrencyINR(this.store.currentPrice());
  });

  readonly formattedCurrentBatchTotal = computed(() => {
    return formatCurrencyINR(this.store.currentPrice() * this.store.quantity());
  });

  readonly currentDisplayImage = computed(() => {
    const p = this.product();
    return this.store.activeGalleryView() === 'front' ? p.frontImage : p.backImage;
  });

  readonly isCurrentImageUploaded = computed(() => {
    const p = this.product();
    return this.store.activeGalleryView() === 'front' ? !!p.frontUploaded : !!p.backUploaded;
  });

  readonly directWhatsAppUrl = computed(() => {
    const p = this.product();
    const size = this.store.selectedSize();
    const qty = this.store.quantity();
    const price = this.store.currentPrice();

    const tempItem = {
      id: `${p.id}_${size}`,
      productId: p.id,
      productName: p.name,
      color: p.color,
      size,
      unitPrice: price,
      quantity: qty,
      image: p.frontImage,
      viewUsed: 'front' as const,
    };

    return generateWhatsAppOrderUrl(this.store.fullWhatsAppNumber(), [tempItem]);
  });

  handleBuyNow() {
    this.store.addToCart();
    this.store.openCheckout();
  }
}
