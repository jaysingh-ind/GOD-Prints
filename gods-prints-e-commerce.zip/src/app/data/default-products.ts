import { Product } from '../models/product.model';

export const DEFAULT_HOODIE_FRONT_SVG = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1000" width="100%" height="100%">
  <defs>
    <!-- Dark Acid Wash Gradients and Textures -->
    <radialGradient id="acidGlow" cx="50%" cy="45%" r="60%">
      <stop offset="0%" stop-color="#1c1c22" />
      <stop offset="50%" stop-color="#131317" />
      <stop offset="100%" stop-color="#0a0a0d" />
    </radialGradient>
    <filter id="distress">
      <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="4" result="noise" />
      <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.18 0" in="noise" result="coloredNoise"/>
      <feComposite operator="in" in="coloredNoise" in2="SourceGraphic" result="textured"/>
      <feBlend mode="overlay" in="textured" in2="SourceGraphic"/>
    </filter>
    <linearGradient id="crimsonGlow" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0%" stop-color="#ff1a40" />
      <stop offset="100%" stop-color="#99001a" />
    </linearGradient>
    <radialGradient id="eyePupil" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="#ffffff" />
      <stop offset="25%" stop-color="#ff3355" />
      <stop offset="70%" stop-color="#b3001e" />
      <stop offset="100%" stop-color="#40000a" />
    </radialGradient>
  </defs>

  <!-- Studio Background -->
  <rect width="800" height="1000" fill="#0c0c0f" />
  <rect width="800" height="1000" fill="url(#acidGlow)" opacity="0.85" />
  
  <!-- Subtle Studio Grid -->
  <line x1="50" y1="50" x2="750" y2="50" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="50" y1="950" x2="750" y2="950" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="50" y1="50" x2="50" y2="950" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="750" y1="50" x2="750" y2="950" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />

  <!-- Technical Spec Watermark Header -->
  <text x="70" y="85" fill="#ffffff" fill-opacity="0.25" font-family="'JetBrains Mono', monospace" font-size="11" letter-spacing="2">GODS PRINTS // FRONT SPECIFICATION</text>
  <text x="730" y="85" text-anchor="end" fill="#e11d48" font-family="'JetBrains Mono', monospace" font-size="11" font-weight="bold" letter-spacing="2">420 GSM FRENCH TERRY</text>

  <!-- Front View Label Indicator -->
  <g transform="translate(400, 130)">
    <rect x="-70" y="-14" width="140" height="28" rx="6" fill="#181820" stroke="#2b2b36" stroke-width="1" />
    <text text-anchor="middle" y="5" fill="#f4f4f5" font-family="'Outfit', sans-serif" font-size="11" font-weight="600" letter-spacing="3">FRONT VIEW</text>
  </g>

  <!-- Hoodie Body Silhouette -->
  <!-- Outer Sleeves -->
  <path d="M 180,310 L 80,620 L 145,640 L 230,470 L 240,780 L 560,780 L 570,470 L 655,640 L 720,620 L 620,310 L 510,210 L 400,230 L 290,210 Z" 
        fill="#141418" stroke="#2c2c36" stroke-width="2" />

  <!-- Acid Wash Mineral Patina Details -->
  <path d="M 240,320 Q 280,380 250,440 T 260,600" stroke="#ffffff" stroke-opacity="0.06" stroke-width="20" stroke-linecap="round" fill="none" />
  <path d="M 540,330 Q 510,400 550,480 T 530,620" stroke="#ffffff" stroke-opacity="0.05" stroke-width="24" stroke-linecap="round" fill="none" />
  <path d="M 330,450 Q 400,430 470,460" stroke="#ffffff" stroke-opacity="0.04" stroke-width="30" stroke-linecap="round" fill="none" />

  <!-- Oversized Double Lined Hood -->
  <path d="M 290,210 Q 400,160 510,210 Q 540,300 480,330 Q 400,345 320,330 Q 260,300 290,210 Z" 
        fill="#181820" stroke="#333340" stroke-width="2" />
  <path d="M 320,240 Q 400,270 480,240 Q 400,310 320,240 Z" fill="#0d0d10" />

  <!-- Thick Streetwear Distressed Drawstrings -->
  <path d="M 365,320 C 360,380 375,440 370,490" stroke="#d4d4d8" stroke-width="4.5" stroke-linecap="round" fill="none" />
  <rect x="366" y="490" width="8" height="18" rx="2" fill="#e11d48" />
  <path d="M 435,320 C 440,380 425,430 430,485" stroke="#d4d4d8" stroke-width="4.5" stroke-linecap="round" fill="none" />
  <rect x="426" y="485" width="8" height="18" rx="2" fill="#e11d48" />

  <!-- Ribbed Hem and Cuffs -->
  <!-- Left Cuff -->
  <path d="M 80,620 L 145,640 L 138,665 L 73,645 Z" fill="#0e0e12" stroke="#272730" stroke-width="1.5" />
  <!-- Right Cuff -->
  <path d="M 655,640 L 720,620 L 727,645 L 662,665 Z" fill="#0e0e12" stroke="#272730" stroke-width="1.5" />
  <!-- Bottom Ribbed Waistband -->
  <rect x="238" y="780" width="324" height="42" rx="4" fill="#101014" stroke="#272730" stroke-width="1.5" />
  <line x1="270" y1="780" x2="270" y2="822" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="330" y1="780" x2="330" y2="822" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="400" y1="780" x2="400" y2="822" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="470" y1="780" x2="470" y2="822" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="530" y1="780" x2="530" y2="822" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />

  <!-- Kangaroo Pocket with Reinforced Bar-tacks -->
  <path d="M 285,630 L 515,630 L 545,770 L 255,770 Z" fill="#16161c" stroke="#2a2a35" stroke-width="1.8" />
  <path d="M 285,630 L 325,770" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <path d="M 515,630 L 475,770" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />

  <!-- Front Chest Anime Artwork: Subtle Shadow Eye & Brand Kanji -->
  <!-- Japanese Kanji Brand mark on left chest -->
  <text x="325" y="415" fill="#ffffff" fill-opacity="0.9" font-family="'Outfit', sans-serif" font-size="13" font-weight="700" letter-spacing="4">GODS PRINTS</text>
  <text x="325" y="432" fill="#e11d48" font-family="'JetBrains Mono', monospace" font-size="10" letter-spacing="2">神の印 // SHADOW 01</text>

  <!-- Glowing Occult Crimson Eye on Center-Right Chest -->
  <g transform="translate(470, 420)">
    <!-- Aura Rings -->
    <circle cx="0" cy="0" r="28" fill="none" stroke="#e11d48" stroke-opacity="0.3" stroke-width="1.5" stroke-dasharray="3 3" />
    <circle cx="0" cy="0" r="22" fill="#120508" stroke="#e11d48" stroke-width="1.5" />
    <!-- Eye Shape -->
    <path d="M -18,0 Q 0,-12 18,0 Q 0,12 -18,0 Z" fill="none" stroke="#ffffff" stroke-width="1.5" />
    <!-- Glowing Iris / Tomoe ring -->
    <circle cx="0" cy="0" r="6" fill="url(#eyePupil)" />
    <!-- 3 Tomoe Occult Comma Marks -->
    <circle cx="0" cy="-4" r="1.5" fill="#ffffff" />
    <circle cx="-3.5" cy="2" r="1.5" fill="#ffffff" />
    <circle cx="3.5" cy="2" r="1.5" fill="#ffffff" />
  </g>

  <!-- Hem Brand Tag -->
  <rect x="250" y="800" width="34" height="22" rx="2" fill="#000000" stroke="#e11d48" stroke-width="1" />
  <text x="267" y="815" text-anchor="middle" fill="#ffffff" font-family="'Outfit', sans-serif" font-size="7" font-weight="bold">GP</text>
  
  <!-- Dimension Footnote -->
  <text x="400" y="910" text-anchor="middle" fill="#71717a" font-family="'JetBrains Mono', monospace" font-size="12" letter-spacing="1">DROP-SHOULDER OVERSIZED SILHOUETTE · ACID WASH BLACK</text>
</svg>
`)}`;

export const DEFAULT_HOODIE_BACK_SVG = `data:image/svg+xml;utf8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1000" width="100%" height="100%">
  <defs>
    <radialGradient id="acidBackGlow" cx="50%" cy="45%" r="65%">
      <stop offset="0%" stop-color="#1e1e26" />
      <stop offset="60%" stop-color="#111116" />
      <stop offset="100%" stop-color="#09090c" />
    </radialGradient>
    <linearGradient id="neonRed" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="#ff264a" />
      <stop offset="50%" stop-color="#e11d48" />
      <stop offset="100%" stop-color="#880016" />
    </linearGradient>
    <linearGradient id="chromeText" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#ffffff" />
      <stop offset="50%" stop-color="#cbd5e1" />
      <stop offset="100%" stop-color="#94a3b8" />
    </linearGradient>
  </defs>

  <!-- Studio Background -->
  <rect width="800" height="1000" fill="#0c0c0f" />
  <rect width="800" height="1000" fill="url(#acidBackGlow)" opacity="0.85" />
  
  <!-- Subtle Technical Borders -->
  <line x1="50" y1="50" x2="750" y2="50" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="50" y1="950" x2="750" y2="950" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="50" y1="50" x2="50" y2="950" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />
  <line x1="750" y1="50" x2="750" y2="950" stroke="#ffffff" stroke-opacity="0.04" stroke-width="1" />

  <!-- Technical Spec Watermark Header -->
  <text x="70" y="85" fill="#ffffff" fill-opacity="0.25" font-family="'JetBrains Mono', monospace" font-size="11" letter-spacing="2">GODS PRINTS // BACK SPECIFICATION</text>
  <text x="730" y="85" text-anchor="end" fill="#e11d48" font-family="'JetBrains Mono', monospace" font-size="11" font-weight="bold" letter-spacing="2">HIGH-DENSITY PUFF &amp; SCREEN</text>

  <!-- Back View Label Indicator -->
  <g transform="translate(400, 130)">
    <rect x="-70" y="-14" width="140" height="28" rx="6" fill="#181820" stroke="#e11d48" stroke-width="1" />
    <text text-anchor="middle" y="5" fill="#ff3b5c" font-family="'Outfit', sans-serif" font-size="11" font-weight="700" letter-spacing="3">BACK VIEW</text>
  </g>

  <!-- Hoodie Body Silhouette (Back) -->
  <path d="M 180,310 L 80,620 L 145,640 L 230,470 L 240,780 L 560,780 L 570,470 L 655,640 L 720,620 L 620,310 L 510,210 L 400,225 L 290,210 Z" 
        fill="#141418" stroke="#2c2c36" stroke-width="2" />

  <!-- Acid Wash Marbling -->
  <path d="M 250,330 Q 230,450 260,550 T 245,680" stroke="#ffffff" stroke-opacity="0.05" stroke-width="28" stroke-linecap="round" fill="none" />
  <path d="M 550,340 Q 570,460 540,560 T 555,690" stroke="#ffffff" stroke-opacity="0.05" stroke-width="26" stroke-linecap="round" fill="none" />
  
  <!-- Back of Hood Resting Down -->
  <path d="M 310,215 Q 400,180 490,215 Q 515,290 480,320 Q 400,340 320,320 Q 285,290 310,215 Z" 
        fill="#181822" stroke="#333342" stroke-width="2" />
  <path d="M 350,230 Q 400,250 450,230 Q 400,310 350,230 Z" fill="#0d0d10" opacity="0.8" />

  <!-- Ribbed Hem and Cuffs -->
  <path d="M 80,620 L 145,640 L 138,665 L 73,645 Z" fill="#0e0e12" stroke="#272730" stroke-width="1.5" />
  <path d="M 655,640 L 720,620 L 727,645 L 662,665 Z" fill="#0e0e12" stroke="#272730" stroke-width="1.5" />
  <rect x="238" y="780" width="324" height="42" rx="4" fill="#101014" stroke="#272730" stroke-width="1.5" />

  <!-- ============================================== -->
  <!-- MASSIVE SIGNATURE ANIME STREETWEAR BACK ARTWORK -->
  <!-- ============================================== -->
  <g transform="translate(400, 520)">
    <!-- Geometric Occult Streetwear Frame -->
    <rect x="-140" y="-190" width="280" height="380" fill="#0f0f13" stroke="#2e2e3a" stroke-width="1.5" />
    <rect x="-132" y="-182" width="264" height="364" fill="none" stroke="#e11d48" stroke-opacity="0.4" stroke-width="1" stroke-dasharray="6 4" />

    <!-- Top Headline of Back Art -->
    <text x="0" y="-155" text-anchor="middle" fill="#ffffff" font-family="'Outfit', sans-serif" font-size="20" font-weight="900" letter-spacing="6">WEAR YOUR POWER</text>
    <text x="0" y="-138" text-anchor="middle" fill="#e11d48" font-family="'JetBrains Mono', monospace" font-size="10" font-weight="bold" letter-spacing="4">神々の力 // CHAOS OCCULT</text>

    <!-- Japanese Vertical Kanji Calligraphy (Sides) -->
    <text x="-105" y="-90" text-anchor="middle" fill="#ffffff" fill-opacity="0.85" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">神</text>
    <text x="-105" y="-60" text-anchor="middle" fill="#ffffff" fill-opacity="0.85" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">聖</text>
    <text x="-105" y="-30" text-anchor="middle" fill="#ffffff" fill-opacity="0.85" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">眼</text>
    <text x="-105" y="0" text-anchor="middle" fill="#e11d48" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">覚</text>
    <text x="-105" y="30" text-anchor="middle" fill="#e11d48" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">醒</text>

    <text x="105" y="-90" text-anchor="middle" fill="#ffffff" fill-opacity="0.85" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">黒</text>
    <text x="105" y="-60" text-anchor="middle" fill="#ffffff" fill-opacity="0.85" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">炎</text>
    <text x="105" y="-30" text-anchor="middle" fill="#ffffff" fill-opacity="0.85" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">破</text>
    <text x="105" y="0" text-anchor="middle" fill="#e11d48" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">滅</text>
    <text x="105" y="30" text-anchor="middle" fill="#e11d48" font-family="'Outfit', sans-serif" font-size="16" font-weight="bold">界</text>

    <!-- Center Anime Artwork: Giant Occult Shadow Eye Array -->
    <!-- Solar Rings -->
    <circle cx="0" cy="-25" r="75" fill="#140508" stroke="#e11d48" stroke-width="2" />
    <circle cx="0" cy="-25" r="85" fill="none" stroke="#ffffff" stroke-opacity="0.15" stroke-width="1.5" stroke-dasharray="4 4" />
    <circle cx="0" cy="-25" r="60" fill="none" stroke="#e11d48" stroke-opacity="0.6" stroke-width="1.5" />

    <!-- Occult Triangle Star Overlay -->
    <polygon points="0,-95 62,12 -62,12" fill="none" stroke="#e11d48" stroke-width="1.5" opacity="0.75" />
    <polygon points="0,45 62,-62 -62,-62" fill="none" stroke="#e11d48" stroke-width="1.5" opacity="0.75" />

    <!-- Giant Almond Eye Contour -->
    <path d="M -58,-25 Q 0,-62 58,-25 Q 0,12 -58,-25 Z" fill="#080002" stroke="#ffffff" stroke-width="2.5" />
    
    <!-- Central Fiery Iris & Black Hole Pupil -->
    <circle cx="0" cy="-25" r="24" fill="url(#neonRed)" />
    <circle cx="0" cy="-25" r="10" fill="#050002" stroke="#ffffff" stroke-width="1" />
    
    <!-- Six Tomoe Commas Spinning Orbit -->
    <circle cx="0" cy="-40" r="3" fill="#ffffff" />
    <circle cx="13" cy="-32" r="3" fill="#ffffff" />
    <circle cx="13" cy="-18" r="3" fill="#ffffff" />
    <circle cx="0" cy="-10" r="3" fill="#ffffff" />
    <circle cx="-13" cy="-18" r="3" fill="#ffffff" />
    <circle cx="-13" cy="-32" r="3" fill="#ffffff" />

    <!-- Lower Typography inside Graphic Frame -->
    <text x="0" y="85" text-anchor="middle" fill="url(#chromeText)" font-family="'Outfit', sans-serif" font-size="28" font-weight="900" letter-spacing="8">SHADOW EYE</text>
    <text x="0" y="112" text-anchor="middle" fill="#ffffff" fill-opacity="0.7" font-family="'JetBrains Mono', monospace" font-size="11" letter-spacing="3">ACID WASH TOKYO STREETWEAR</text>
    <text x="0" y="130" text-anchor="middle" fill="#e11d48" font-family="'JetBrains Mono', monospace" font-size="10" letter-spacing="2">EST. 2026 // EDITION 01</text>
    
    <!-- Barcode at Base of Art -->
    <g transform="translate(-70, 145)">
      <line x1="0" y1="0" x2="0" y2="24" stroke="#ffffff" stroke-width="2" />
      <line x1="5" y1="0" x2="5" y2="24" stroke="#ffffff" stroke-width="1" />
      <line x1="9" y1="0" x2="9" y2="24" stroke="#ffffff" stroke-width="3" />
      <line x1="16" y1="0" x2="16" y2="24" stroke="#ffffff" stroke-width="1" />
      <line x1="22" y1="0" x2="22" y2="24" stroke="#ffffff" stroke-width="2" />
      <line x1="28" y1="0" x2="28" y2="24" stroke="#ffffff" stroke-width="4" />
      <line x1="36" y1="0" x2="36" y2="24" stroke="#ffffff" stroke-width="1" />
      <line x1="42" y1="0" x2="42" y2="24" stroke="#ffffff" stroke-width="3" />
      <line x1="50" y1="0" x2="50" y2="24" stroke="#ffffff" stroke-width="2" />
      <line x1="56" y1="0" x2="56" y2="24" stroke="#ffffff" stroke-width="1" />
      <line x1="62" y1="0" x2="62" y2="24" stroke="#ffffff" stroke-width="4" />
      <line x1="72" y1="0" x2="72" y2="24" stroke="#ffffff" stroke-width="1" />
      <line x1="80" y1="0" x2="80" y2="24" stroke="#ffffff" stroke-width="3" />
      <line x1="90" y1="0" x2="90" y2="24" stroke="#ffffff" stroke-width="2" />
      <line x1="96" y1="0" x2="96" y2="24" stroke="#ffffff" stroke-width="1" />
      <line x1="104" y1="0" x2="104" y2="24" stroke="#ffffff" stroke-width="3" />
      <line x1="114" y1="0" x2="114" y2="24" stroke="#ffffff" stroke-width="2" />
      <line x1="122" y1="0" x2="122" y2="24" stroke="#ffffff" stroke-width="1" />
      <line x1="130" y1="0" x2="130" y2="24" stroke="#ffffff" stroke-width="3" />
      <line x1="138" y1="0" x2="138" y2="24" stroke="#ffffff" stroke-width="2" />
    </g>
  </g>

  <!-- Dimension Footnote -->
  <text x="400" y="910" text-anchor="middle" fill="#71717a" font-family="'JetBrains Mono', monospace" font-size="12" letter-spacing="1">FULL-BACK SILKSCREEN &amp; PUFF EMBOSSING</text>
</svg>
`)}`;

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'shadow-eye-acid-wash-hoodie',
    name: 'Shadow Eye Acid Wash Hoodie',
    subtitle: 'Heavyweight 420 GSM Drop-Shoulder French Terry',
    color: 'Black',
    colorHex: '#141416',
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
    basePrice: 1499,
    price3XL: 1599,
    frontImage: '/assets/images/shadow-eye-hoodie-front.png',
    backImage: '/assets/images/shadow-eye-hoodie-back.png',
    frontImageName: 'shadow-eye-hoodie-front.png',
    backImageName: 'shadow-eye-hoodie-back.png',
    frontUploaded: true,
    backUploaded: true,
    description:
      'Forged in darkness and crowned by the occult anime aesthetic. Crafted from ultra-heavyweight 420 GSM 100% French Terry cotton, undergoing a bespoke artisan mineral acid wash that creates an unrepeatable vintage patina on every individual garment. Features a subtle front chest ocular seal with Japanese kanji and an epic oversized full-back graphic with high-density puff detailing.',
    features: [
      '420 GSM ultra-heavyweight 100% French Terry combed cotton',
      'Handcrafted artisan mineral acid-wash vintage treatment',
      'Dual high-density silkscreen + tactile puff print combination',
      'Oversized drop-shoulder silhouette with structured double-lined hood',
      'Heavyweight 2x2 ribbed cuffs & hem with reinforced bar-tack stitching',
      'Pre-shrunk fabric ensuring zero distortion across multiple washes',
    ],
    fabric: '100% Combed French Terry Cotton (420 GSM)',
    fit: 'Oversized Streetwear Drop-Shoulder Fit',
    gsm: 420,
    washCare: [
      'Machine wash cold (30°C / 86°F) inside out',
      'Do not bleach or dry clean',
      'Tumble dry low or hang dry in shade for maximum longevity',
      'Iron inside out on low heat; do not iron directly on print',
    ],
    inStock: true,
    isFeatured: true,
    isPublished: true,
    category: 'Hoodies',
    badge: 'DROP 01 // LIMITED EDITION',
  },
];
