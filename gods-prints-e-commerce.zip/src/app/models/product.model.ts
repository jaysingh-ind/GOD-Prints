export type HoodieSize = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL' | '3XL';

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  color: string;
  colorHex: string;
  sizes: HoodieSize[];
  basePrice: number;       // ₹1,499 for XS to XXL
  price3XL: number;        // ₹1,599 for 3XL
  frontImage: string;      // Base64 Data URL or asset path
  backImage: string;       // Base64 Data URL or asset path
  frontImageName?: string;
  backImageName?: string;
  frontUploaded?: boolean;
  backUploaded?: boolean;
  additionalImages?: string[];
  additionalImageNames?: string[];
  description: string;
  features: string[];
  fabric: string;
  fit: string;
  gsm: number;
  washCare: string[];
  inStock: boolean;
  isFeatured: boolean;
  isPublished: boolean;    // Controlled in Admin Studio (Draft vs Live)
  category: string;
  badge?: string;
}

export interface CartItem {
  id: string;            // unique per item + size
  productId: string;
  productName: string;
  color: string;
  size: HoodieSize;
  unitPrice: number;
  quantity: number;
  image: string;
  viewUsed: 'front' | 'back';
}

export interface OrderCustomerDetails {
  fullName: string;
  phone: string;
  email?: string;
  address: string;
  city: string;
  pincode: string;
  orderNotes?: string;
  paymentMethod: 'prepaid_upi' | 'whatsapp_confirm';
}

export interface CartTotals {
  subtotal: number;
  shipping: number;
  total: number;
  itemCount: number;
  freeShippingQualified: boolean;
  amountNeededForFreeShipping: number;
}

export interface StoreSettings {
  countryCode: string;          // e.g. "+91"
  whatsappPhone: string;        // e.g. "9876543210"
  contactEmail: string;         // e.g. "concierge@godsprints.in"
  instagram: string;            // e.g. "@godsprints"
  storeLocation: string;        // e.g. "India Studio"
  brandBio: string;
  paymentNotice: string;        // "PREPAID ORDERS ONLY · NO CASH ON DELIVERY"
  paymentUpiId: string;         // e.g. "godsprints@upi"
  paymentInstructions: string;
  returnHours: number;          // 24
  returnPolicyText: string;
  adminPin?: string;
}

export interface ReturnRequest {
  orderId: string;
  customerName: string;
  phone: string;
  reason: 'transit_damage' | 'sizing_mismatch' | 'wrong_item' | 'other';
  reasonText: string;
  description: string;
}
