import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateItemPrice,
  calculateCartTotals,
  formatCurrencyINR,
  generateWhatsAppOrderUrl,
  generateWhatsAppReturnUrl,
  validateImageFile,
  cleanWhatsAppPhoneNumber,
} from './store-logic';
import { CartItem, ReturnRequest } from '../models/product.model';

test('calculateItemPrice correctly charges basePrice ₹1,499 for XS to XXL and ₹1,599 for 3XL', () => {
  const basePrice = 1499;
  const price3XL = 1599;

  assert.equal(calculateItemPrice(basePrice, price3XL, 'XS'), 1499);
  assert.equal(calculateItemPrice(basePrice, price3XL, 'S'), 1499);
  assert.equal(calculateItemPrice(basePrice, price3XL, 'M'), 1499);
  assert.equal(calculateItemPrice(basePrice, price3XL, 'L'), 1499);
  assert.equal(calculateItemPrice(basePrice, price3XL, 'XL'), 1499);
  assert.equal(calculateItemPrice(basePrice, price3XL, 'XXL'), 1499);
  assert.equal(calculateItemPrice(basePrice, price3XL, '3XL'), 1599);
});

test('calculateCartTotals calculates accurate subtotal, shipping, and free shipping progress', () => {
  const item1: CartItem = {
    id: 'prod-1-L',
    productId: 'prod-1',
    productName: 'Shadow Eye Acid Wash Hoodie',
    color: 'Black',
    size: 'L',
    unitPrice: 1499,
    quantity: 1,
    image: '',
    viewUsed: 'front',
  };

  const totals = calculateCartTotals([item1]);
  assert.equal(totals.itemCount, 1);
  assert.equal(totals.subtotal, 1499);
  assert.equal(totals.shipping, 0); // Free shipping threshold is >= ₹999
  assert.equal(totals.freeShippingQualified, true);
  assert.equal(totals.total, 1499);

  // Test item below free shipping threshold
  const cheapItem: CartItem = {
    id: 'tee-1-M',
    productId: 'tee-1',
    productName: 'Sticker Pack',
    color: 'Multi',
    size: 'M',
    unitPrice: 499,
    quantity: 1,
    image: '',
    viewUsed: 'front',
  };

  const cheapTotals = calculateCartTotals([cheapItem]);
  assert.equal(cheapTotals.subtotal, 499);
  assert.equal(cheapTotals.shipping, 99);
  assert.equal(cheapTotals.total, 598);
  assert.equal(cheapTotals.freeShippingQualified, false);
  assert.equal(cheapTotals.amountNeededForFreeShipping, 500);
});

test('formatCurrencyINR formats numbers in standard Indian Rupee notation', () => {
  assert.equal(formatCurrencyINR(1499), '₹1,499');
  assert.equal(formatCurrencyINR(1599), '₹1,599');
  assert.equal(formatCurrencyINR(0), '₹0');
  assert.equal(formatCurrencyINR(9999), '₹9,999');
});

test('generateWhatsAppOrderUrl builds valid wa.me link with encoded details and NO COD notice', () => {
  const item: CartItem = {
    id: 'hoodie-3xl',
    productId: 'hoodie',
    productName: 'Shadow Eye Acid Wash Hoodie',
    color: 'Black',
    size: '3XL',
    unitPrice: 1599,
    quantity: 2,
    image: '',
    viewUsed: 'front',
  };

  const url = generateWhatsAppOrderUrl('+91 98765 43210', [item], {
    fullName: 'Arjun Verma',
    phone: '9876543210',
    address: 'Flat 402, Neo Heights',
    city: 'Bengaluru',
    pincode: '560001',
    paymentMethod: 'prepaid_upi',
  }, 'GP-10928');

  assert.ok(url.startsWith('https://wa.me/919876543210?text='));
  const decoded = decodeURIComponent(url);
  assert.ok(decoded.includes('Shadow Eye Acid Wash Hoodie'));
  assert.ok(decoded.includes('Size: 3XL'));
  assert.ok(decoded.includes('#GP-10928'));
  assert.ok(decoded.includes('PREPAID ORDERS ONLY · NO CASH ON DELIVERY'));
  assert.ok(decoded.includes('Bengaluru - 560001'));
});

test('generateWhatsAppReturnUrl builds valid return request link with order reference and photo requirement', () => {
  const req: ReturnRequest = {
    orderId: 'GP-84920',
    customerName: 'Ishaan Roy',
    phone: '9876543210',
    reason: 'transit_damage',
    reasonText: 'Transit Damage / Torn Packaging',
    description: 'Hoodie outer packaging had a tear and seam was damaged upon arrival.',
  };

  const url = generateWhatsAppReturnUrl('+91 9876543210', req);
  assert.ok(url.startsWith('https://wa.me/919876543210?text='));
  const decoded = decodeURIComponent(url);
  assert.ok(decoded.includes('RETURN / EXCHANGE REQUEST'));
  assert.ok(decoded.includes('#GP-84920'));
  assert.ok(decoded.includes('Transit Damage'));
  assert.ok(decoded.includes('MANDATORY ATTACHMENT'));
});

test('validateImageFile rejects non-images and oversized files and permits up to 25MB', () => {
  assert.equal(validateImageFile({ size: 1000, type: 'text/plain' }).valid, false);
  assert.equal(validateImageFile({ size: 30 * 1024 * 1024, type: 'image/jpeg' }).valid, false);
  assert.equal(validateImageFile({ size: 20 * 1024 * 1024, type: 'image/jpeg' }).valid, true);
  assert.equal(validateImageFile({ size: 2 * 1024 * 1024, type: 'image/png' }).valid, true);
});

test('cleanWhatsAppPhoneNumber removes non-numeric characters', () => {
  assert.equal(cleanWhatsAppPhoneNumber('+91 (987) 654-3210'), '919876543210');
  assert.equal(cleanWhatsAppPhoneNumber('9876543210'), '9876543210');
});
