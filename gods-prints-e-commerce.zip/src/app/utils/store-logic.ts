import { CartItem, CartTotals, HoodieSize, ReturnRequest } from '../models/product.model';

/**
 * Calculates item price based on selected size.
 * Base price for XS to XXL, separate price tier for 3XL.
 */
export function calculateItemPrice(basePrice: number, price3XL: number, size: HoodieSize): number {
  if (size === '3XL') {
    return price3XL;
  }
  return basePrice;
}

/**
 * Formats a numeric value into standard Indian Rupee notation (₹X,XXX).
 */
export function formatCurrencyINR(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

/**
 * Calculates cart subtotal, shipping charges, free shipping qualification, and total.
 * Free express shipping above ₹999.
 */
export function calculateCartTotals(items: CartItem[]): CartTotals {
  const FREE_SHIPPING_THRESHOLD = 999;
  const STANDARD_SHIPPING_FEE = 99;

  const subtotal = items.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const itemCount = items.reduce((sum, item) => sum + item.quantity, 0);

  const freeShippingQualified = subtotal >= FREE_SHIPPING_THRESHOLD && itemCount > 0;
  const shipping = items.length === 0 || freeShippingQualified ? 0 : STANDARD_SHIPPING_FEE;
  const total = subtotal + shipping;
  const amountNeededForFreeShipping = Math.max(0, FREE_SHIPPING_THRESHOLD - subtotal);

  return {
    subtotal,
    shipping,
    total,
    itemCount,
    freeShippingQualified,
    amountNeededForFreeShipping,
  };
}

/**
 * Cleans phone number with country code for wa.me links.
 */
export function cleanWhatsAppPhoneNumber(phoneWithOrWithoutCode: string): string {
  return phoneWithOrWithoutCode.replace(/[^0-9]/g, '');
}

/**
 * Formats WhatsApp order link with structured message.
 * Enforces NO CASH ON DELIVERY and requires payment confirmation.
 */
export function generateWhatsAppOrderUrl(
  phone: string,
  items: CartItem[],
  customer?: {
    fullName: string;
    phone: string;
    address: string;
    city: string;
    pincode: string;
    paymentMethod?: string;
  },
  orderId?: string
): string {
  const cleanPhone = cleanWhatsAppPhoneNumber(phone);
  const totals = calculateCartTotals(items);

  let message = `*⚡ NEW ORDER INQUIRY — GODS PRINTS* ⚡\n`;
  if (orderId) {
    message += `*Order Reference:* #${orderId}\n`;
  }
  message += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
  message += `*ORDER ITEMS:*\n`;

  items.forEach((item, index) => {
    message += `${index + 1}. *${item.productName}*\n`;
    message += `   • Size: ${item.size}\n`;
    message += `   • Color: ${item.color}\n`;
    message += `   • Qty: ${item.quantity}\n`;
    message += `   • Price: ${formatCurrencyINR(item.unitPrice * item.quantity)}\n\n`;
  });

  message += `━━━━━━━━━━━━━━━━━━━━━━\n`;
  message += `*Subtotal:* ${formatCurrencyINR(totals.subtotal)}\n`;
  message += `*Shipping:* ${totals.shipping === 0 ? 'FREE EXPRESS' : formatCurrencyINR(totals.shipping)}\n`;
  message += `*TOTAL PAYABLE:* ${formatCurrencyINR(totals.total)}\n\n`;

  message += `*PAYMENT POLICY:*\n`;
  message += `⚠️ *PREPAID ORDERS ONLY · NO CASH ON DELIVERY*\n`;
  message += `Orders are placed into fulfillment queue once payment is verified via UPI / Net Banking.\n\n`;

  if (customer && customer.fullName) {
    message += `*CUSTOMER & DELIVERY DETAILS:*\n`;
    message += `• Name: ${customer.fullName}\n`;
    message += `• Contact Phone: ${customer.phone}\n`;
    message += `• Address: ${customer.address}\n`;
    message += `• City / Pincode: ${customer.city} - ${customer.pincode}\n\n`;
  }

  message += `Please share UPI QR / payment instructions to confirm this order.`;

  const encoded = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encoded}`;
}

/**
 * Generates WhatsApp return inquiry message within 24 hours of delivery.
 */
export function generateWhatsAppReturnUrl(
  phone: string,
  request: ReturnRequest
): string {
  const cleanPhone = cleanWhatsAppPhoneNumber(phone);

  let message = `*🚨 RETURN / EXCHANGE REQUEST — GODS PRINTS* 🚨\n`;
  message += `━━━━━━━━━━━━━━━━━━━━━━\n`;
  message += `*Order ID:* #${request.orderId}\n`;
  message += `*Customer Name:* ${request.customerName}\n`;
  message += `*Contact Phone:* ${request.phone}\n`;
  message += `*Reason:* ${request.reasonText}\n\n`;
  message += `*Claim Details:*\n${request.description}\n\n`;
  message += `━━━━━━━━━━━━━━━━━━━━━━\n`;
  message += `📸 *MANDATORY ATTACHMENT:*\n`;
  message += `As per the 24-Hour Return Policy, I have attached photos/video of the unboxing and product tags below.\n\n`;
  message += `Please review and initiate replacement/resolution.`;

  const encoded = encodeURIComponent(message);
  return `https://wa.me/${cleanPhone}?text=${encoded}`;
}

/**
 * Validates uploaded image file size and MIME type.
 * Preserves uncompressed original resolution up to 25MB.
 */
export function validateImageFile(file: { size: number; type: string }): { valid: boolean; error?: string } {
  const MAX_SIZE = 25 * 1024 * 1024; // 25MB max to preserve uncompressed raw studio quality
  if (!file.type.startsWith('image/')) {
    return { valid: false, error: 'Please upload a valid image file (PNG, JPG, WEBP, or SVG).' };
  }
  if (file.size > MAX_SIZE) {
    return { valid: false, error: 'Image file size exceeds the 25MB limit.' };
  }
  return { valid: true };
}
