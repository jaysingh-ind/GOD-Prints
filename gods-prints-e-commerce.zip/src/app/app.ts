import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { StoreService } from './services/store.service';
import { HeaderComponent } from './components/header/header';
import { HeroComponent } from './components/hero/hero';
import { ProductShowcaseComponent } from './components/product-showcase/product-showcase';
import { FeaturedProductsComponent } from './components/featured-products/featured-products';
import { AboutComponent } from './components/about/about';
import { ContactComponent } from './components/contact/contact';
import { FooterComponent } from './components/footer/footer';
import { CartDrawerComponent } from './components/cart-drawer/cart-drawer';
import { AdminModalComponent } from './components/admin-modal/admin-modal';
import { CheckoutModalComponent } from './components/checkout-modal/checkout-modal';
import { SizeGuideModalComponent } from './components/size-guide-modal/size-guide-modal';
import { ZoomModalComponent } from './components/zoom-modal/zoom-modal';
import { ReturnModalComponent } from './components/return-modal/return-modal';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    HeroComponent,
    ProductShowcaseComponent,
    FeaturedProductsComponent,
    AboutComponent,
    ContactComponent,
    FooterComponent,
    CartDrawerComponent,
    AdminModalComponent,
    CheckoutModalComponent,
    SizeGuideModalComponent,
    ZoomModalComponent,
    ReturnModalComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly store = inject(StoreService);
}
