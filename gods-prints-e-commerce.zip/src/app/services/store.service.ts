import { Injectable, computed, effect, signal } from '@angular/core';
import {
  CartItem,
  CartTotals,
  HoodieSize,
  Product,
  StoreSettings,
  OrderCustomerDetails,
} from '../models/product.model';
import { INITIAL_PRODUCTS } from '../data/default-products';
import {
  calculateCartTotals,
  calculateItemPrice,
  cleanWhatsAppPhoneNumber,
  generateWhatsAppOrderUrl,
} from '../utils/store-logic';
import {
  saveHighResImage,
  getHighResImage,
  removeHighResImage,
  clearAllHighResImages,
} from '../utils/image-storage';

const STORAGE_KEY_PRODUCTS = 'gods_prints_products_v3';
const STORAGE_KEY_CART = 'gods_prints_cart_v2';
const STORAGE_KEY_SETTINGS = 'gods_prints_settings_v2';
const STORAGE_KEY_ADMIN_AUTH = 'gods_prints_admin_session';

const DEFAULT_SETTINGS: StoreSettings = {
  countryCode: '+91',
  whatsappPhone: '9876543210',
  contactEmail: 'concierge@godsprints.in',
  instagram: '@godsprints',
  storeLocation: 'India Studio · Direct-to-Consumer Streetwear',
  brandBio:
    'GODS PRINTS is an independent streetwear atelier crafting ultra-heavyweight Japanese street cuts, occult anime iconography, and artisan mineral acid washes. 100% combed cotton, zero compromises.',
  paymentNotice: 'PREPAID ORDERS ONLY · NO CASH ON DELIVERY',
  paymentUpiId: 'godsprints@upi',
  paymentInstructions:
    'All orders are processed and queued for dispatch immediately upon receipt of payment confirmation. Once you submit your order, share the confirmation on WhatsApp to receive the payment QR / UPI handle.',
  returnHours: 24,
  returnPolicyText:
    'Return requests must be initiated within 24 hours of package delivery via our WhatsApp line. Due to our limited drop production, returns are accepted exclusively for transit damage or verified sizing mismatch with original product tags and unboxing photos. Claims are evaluated within 24 hours.',
};

@Injectable({
  providedIn: 'root',
})
export class StoreService {
  // ==========================================
  // 1. PRODUCTS STATE & COMPUTED PROPERTIES
  // ==========================================
  readonly products = signal<Product[]>(this.loadProductsFromStorage());
  readonly activeProductId = signal<string>('shadow-eye-acid-wash-hoodie');

  // Customer-facing published products (Unpublished/draft products are hidden from public shop)
  readonly publishedProducts = computed<Product[]>(() => {
    return this.products().filter((p) => p.isPublished !== false);
  });

  // Featured products for capsule showcase
  readonly featuredProducts = computed<Product[]>(() => {
    return this.publishedProducts().filter((p) => p.isFeatured);
  });

  // Active PDP product
  readonly activeProduct = computed<Product>(() => {
    const pubList = this.publishedProducts();
    const found = pubList.find((p) => p.id === this.activeProductId());
    if (found) return found;
    // Fallback to any product
    const allList = this.products();
    const foundInAll = allList.find((p) => p.id === this.activeProductId());
    return foundInAll || pubList[0] || allList[0] || INITIAL_PRODUCTS[0];
  });

  // PDP Selection state
  readonly selectedSize = signal<HoodieSize>('L');
  readonly activeGalleryView = signal<'front' | 'back' | 'additional_0' | 'additional_1'>('front');
  readonly quantity = signal<number>(1);

  // Computed current unit price based on selected size
  readonly currentPrice = computed<number>(() => {
    const p = this.activeProduct();
    return calculateItemPrice(p.basePrice, p.price3XL, this.selectedSize());
  });

  // ==========================================
  // 2. STORE SETTINGS & BUSINESS DETAILS
  // ==========================================
  readonly settings = signal<StoreSettings>(this.loadSettingsFromStorage());

  // Clean full WhatsApp phone number with country code for links
  readonly fullWhatsAppNumber = computed<string>(() => {
    const s = this.settings();
    return cleanWhatsAppPhoneNumber(s.countryCode + s.whatsappPhone);
  });

  // Formatted display phone number
  readonly displayWhatsAppNumber = computed<string>(() => {
    const s = this.settings();
    return `${s.countryCode} ${s.whatsappPhone}`;
  });

  // ==========================================
  // 3. CART STATE & COMPUTED METRICS
  // ==========================================
  readonly cart = signal<CartItem[]>(this.loadCartFromStorage());

  readonly cartTotals = computed<CartTotals>(() => {
    return calculateCartTotals(this.cart());
  });

  readonly cartCount = computed<number>(() => {
    return this.cart().reduce((sum, item) => sum + item.quantity, 0);
  });

  // ==========================================
  // 4. UI MODALS & DRAWERS STATE
  // ==========================================
  readonly isCartOpen = signal<boolean>(false);
  readonly isAdminOpen = signal<boolean>(false);
  readonly isSizeGuideOpen = signal<boolean>(false);
  readonly isCheckoutOpen = signal<boolean>(false);
  readonly isZoomOpen = signal<boolean>(false);
  readonly isReturnModalOpen = signal<boolean>(false);
  readonly toastMessage = signal<string | null>(null);

  // ==========================================
  // 5. ADMIN AUTHENTICATION
  // ==========================================
  readonly isAdminAuthenticated = signal<boolean>(this.loadAdminSession());
  readonly adminAuthError = signal<string | null>(null);

  constructor() {
    // 1. Auto-persist products to localStorage
    effect(() => {
      const prods = this.products();
      if (typeof window !== 'undefined' && window.localStorage) {
        try {
          window.localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(prods));
        } catch (e) {
          console.warn('Failed to persist products to localStorage:', e);
        }
      }
    });

    // 2. Auto-persist settings to localStorage
    effect(() => {
      const s = this.settings();
      if (typeof window !== 'undefined' && window.localStorage) {
        try {
          window.localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(s));
        } catch (e) {
          console.warn('Failed to persist settings to localStorage:', e);
        }
      }
    });

    // 3. Auto-persist cart to localStorage
    effect(() => {
      const items = this.cart();
      if (typeof window !== 'undefined' && window.localStorage) {
        try {
          window.localStorage.setItem(STORAGE_KEY_CART, JSON.stringify(items));
        } catch (e) {
          console.warn('Failed to persist cart to localStorage:', e);
        }
      }
    });

    // 4. Client hydration from server API and IndexedDB
    if (typeof window !== 'undefined') {
      this.syncFromServer();
      this.hydrateHighResImages();
    }
  }

  // ==========================================
  // 6. SYNC & PERSISTENCE
  // ==========================================
  private async syncFromServer() {
    try {
      // Sync products
      const prodRes = await fetch('/api/products');
      if (prodRes.ok) {
        const data = await prodRes.json();
        if (data.success && Array.isArray(data.products) && data.products.length > 0) {
          this.products.set(data.products);
        }
      }
    } catch {
      // Offline or SSR mode
    }

    try {
      // Sync settings
      const setRes = await fetch('/api/settings');
      if (setRes.ok) {
        const data = await setRes.json();
        if (data.success && data.settings) {
          this.settings.update((curr) => ({ ...curr, ...data.settings }));
        }
      }
    } catch {
      // Offline or SSR mode
    }
  }

  private async persistProductsToServer(prods: Product[]) {
    try {
      await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ products: prods }),
      });
    } catch {
      // Local fallback active
    }
  }

  private async persistSettingsToServer(settings: StoreSettings) {
    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
    } catch {
      // Local fallback active
    }
  }

  private async hydrateHighResImages() {
    if (typeof window === 'undefined' || !window.indexedDB) return;
    try {
      const prods = this.products();
      let hasUpdates = false;
      const updatedList = await Promise.all(
        prods.map(async (p) => {
          const frontSaved = await getHighResImage(`${p.id}_front`);
          const backSaved = await getHighResImage(`${p.id}_back`);
          const newP = { ...p };
          if (frontSaved && frontSaved.dataUrl) {
            newP.frontImage = frontSaved.dataUrl;
            if (frontSaved.fileName) newP.frontImageName = frontSaved.fileName;
            newP.frontUploaded = true;
            hasUpdates = true;
          }
          if (backSaved && backSaved.dataUrl) {
            newP.backImage = backSaved.dataUrl;
            if (backSaved.fileName) newP.backImageName = backSaved.fileName;
            newP.backUploaded = true;
            hasUpdates = true;
          }
          return newP;
        })
      );
      if (hasUpdates) {
        this.products.set(updatedList);
      }
    } catch (e) {
      console.warn('Hydrating high-res images:', e);
    }
  }

  private loadProductsFromStorage(): Product[] {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY_PRODUCTS);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed) && parsed.length > 0) {
            return parsed;
          }
        }
      } catch (e) {
        console.warn('Error reading products from localStorage:', e);
      }
    }
    return INITIAL_PRODUCTS;
  }

  private loadSettingsFromStorage(): StoreSettings {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY_SETTINGS);
        if (raw) {
          const parsed = JSON.parse(raw);
          return { ...DEFAULT_SETTINGS, ...parsed };
        }
      } catch (e) {
        console.warn('Error reading settings from localStorage:', e);
      }
    }
    return DEFAULT_SETTINGS;
  }

  private loadCartFromStorage(): CartItem[] {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        const raw = window.localStorage.getItem(STORAGE_KEY_CART);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch (e) {
        console.warn('Error reading cart from localStorage:', e);
      }
    }
    return [];
  }

  private loadAdminSession(): boolean {
    if (typeof window !== 'undefined' && window.sessionStorage) {
      return window.sessionStorage.getItem(STORAGE_KEY_ADMIN_AUTH) === 'true';
    }
    return false;
  }

  // ==========================================
  // 7. PRODUCT MANAGEMENT (ADMIN ACTIONS)
  // ==========================================
  selectProduct(productId: string) {
    this.activeProductId.set(productId);
    this.selectedSize.set('L');
    this.activeGalleryView.set('front');
    this.quantity.set(1);
  }

  setSize(size: HoodieSize) {
    this.selectedSize.set(size);
  }

  setGalleryView(view: 'front' | 'back' | 'additional_0' | 'additional_1') {
    this.activeGalleryView.set(view);
  }

  setQuantity(qty: number) {
    if (qty >= 1 && qty <= 10) {
      this.quantity.set(qty);
    }
  }

  incrementQuantity() {
    this.quantity.update((q) => Math.min(10, q + 1));
  }

  decrementQuantity() {
    this.quantity.update((q) => Math.max(1, q - 1));
  }

  // Add unlimited products
  addProduct(newProduct: Partial<Product>): Product {
    const id = (newProduct.name || 'apparel')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '') + '-' + Date.now().toString().slice(-4);

    const fullProduct: Product = {
      id,
      name: newProduct.name || 'New Custom Piece',
      subtitle: newProduct.subtitle || 'Premium Heavyweight Japanese Streetwear Cut',
      color: newProduct.color || 'Black',
      colorHex: newProduct.colorHex || '#141416',
      sizes: newProduct.sizes || ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'],
      basePrice: newProduct.basePrice || 1499,
      price3XL: newProduct.price3XL || 1599,
      frontImage: newProduct.frontImage || '/assets/images/shadow-eye-hoodie-front.png',
      backImage: newProduct.backImage || '/assets/images/shadow-eye-hoodie-back.png',
      frontImageName: newProduct.frontImageName || 'front-view.png',
      backImageName: newProduct.backImageName || 'back-view.png',
      frontUploaded: !!newProduct.frontUploaded,
      backUploaded: !!newProduct.backUploaded,
      additionalImages: newProduct.additionalImages || [],
      additionalImageNames: newProduct.additionalImageNames || [],
      description:
        newProduct.description ||
        'Handcrafted with obsession. Heavyweight combed French Terry cotton with bespoke acid wash vintage patina.',
      features: newProduct.features || [
        '100% Combed Heavyweight Cotton',
        'Drop-shoulder boxy streetwear drape',
        'Tactile high-density print',
      ],
      fabric: newProduct.fabric || '100% Combed French Terry Cotton',
      fit: newProduct.fit || 'Oversized Streetwear Drop-Shoulder Fit',
      gsm: newProduct.gsm || 420,
      washCare: newProduct.washCare || ['Machine wash cold inside out', 'Dry flat in shade'],
      inStock: newProduct.inStock !== undefined ? newProduct.inStock : true,
      isFeatured: newProduct.isFeatured !== undefined ? newProduct.isFeatured : true,
      isPublished: newProduct.isPublished !== undefined ? newProduct.isPublished : true,
      category: newProduct.category || 'Hoodies',
      badge: newProduct.badge || 'NEW ARRIVAL',
    };

    this.products.update((list) => [fullProduct, ...list]);
    this.selectProduct(fullProduct.id);
    this.persistProductsToServer(this.products());
    this.showToast(`Product "${fullProduct.name}" created and added to shop!`);
    return fullProduct;
  }

  updateProduct(updated: Product) {
    this.products.update((list) => {
      return list.map((p) => (p.id === updated.id ? updated : p));
    });
    this.persistProductsToServer(this.products());
    this.showToast(`Updated "${updated.name}" successfully`);
  }

  deleteProduct(productId: string) {
    const remaining = this.products().filter((p) => p.id !== productId);
    if (remaining.length === 0) {
      this.showToast('At least one product must remain in catalog.');
      return;
    }
    this.products.set(remaining);
    this.persistProductsToServer(remaining);
    if (this.activeProductId() === productId) {
      this.selectProduct(remaining[0].id);
    }
    this.showToast('Product removed from catalog.');
  }

  togglePublishProduct(productId: string) {
    this.products.update((list) => {
      return list.map((p) => {
        if (p.id === productId) {
          const next = !p.isPublished;
          return { ...p, isPublished: next };
        }
        return p;
      });
    });
    this.persistProductsToServer(this.products());
    const prod = this.products().find((p) => p.id === productId);
    this.showToast(
      prod?.isPublished ? `"${prod.name}" is now LIVE in Shop!` : `"${prod?.name}" set to DRAFT (Hidden from Shop)`
    );
  }

  async uploadProductImage(
    productId: string,
    view: 'front' | 'back' | 'additional',
    dataUrl: string,
    fileName?: string,
    additionalIndex = 0
  ) {
    // 1. Save uncompressed high-resolution original image to IndexedDB
    const storageKey = view === 'additional' ? `${productId}_add_${additionalIndex}` : `${productId}_${view}`;
    await saveHighResImage(storageKey, dataUrl, fileName);

    // 2. Update reactive product signal
    this.products.update((list) => {
      return list.map((p) => {
        if (p.id === productId) {
          if (view === 'front') {
            return {
              ...p,
              frontImage: dataUrl,
              frontImageName: fileName || 'Uploaded Front View',
              frontUploaded: true,
            };
          } else if (view === 'back') {
            return {
              ...p,
              backImage: dataUrl,
              backImageName: fileName || 'Uploaded Back View',
              backUploaded: true,
            };
          } else {
            const addImages = [...(p.additionalImages || [])];
            const addNames = [...(p.additionalImageNames || [])];
            addImages[additionalIndex] = dataUrl;
            addNames[additionalIndex] = fileName || `Detail ${additionalIndex + 1}`;
            return {
              ...p,
              additionalImages: addImages,
              additionalImageNames: addNames,
            };
          }
        }
        return p;
      });
    });

    this.persistProductsToServer(this.products());
    this.showToast(`${view.toUpperCase()} image updated at full original resolution!`);
  }

  async deleteProductImage(productId: string, view: 'front' | 'back' | 'additional', additionalIndex = 0) {
    const storageKey = view === 'additional' ? `${productId}_add_${additionalIndex}` : `${productId}_${view}`;
    await removeHighResImage(storageKey);

    this.products.update((list) => {
      return list.map((p) => {
        if (p.id === productId) {
          if (view === 'front') {
            return {
              ...p,
              frontImage: '/assets/images/shadow-eye-hoodie-front.png',
              frontImageName: 'shadow-eye-hoodie-front.png',
              frontUploaded: true,
            };
          } else if (view === 'back') {
            return {
              ...p,
              backImage: '/assets/images/shadow-eye-hoodie-back.png',
              backImageName: 'shadow-eye-hoodie-back.png',
              backUploaded: true,
            };
          } else {
            const addImages = [...(p.additionalImages || [])];
            const addNames = [...(p.additionalImageNames || [])];
            addImages.splice(additionalIndex, 1);
            addNames.splice(additionalIndex, 1);
            return {
              ...p,
              additionalImages: addImages,
              additionalImageNames: addNames,
            };
          }
        }
        return p;
      });
    });

    this.persistProductsToServer(this.products());
    this.showToast(`Reset ${view} image to standard spec.`);
  }

  // ==========================================
  // 8. SETTINGS MANAGEMENT
  // ==========================================
  updateSettings(updates: Partial<StoreSettings>) {
    this.settings.update((curr) => {
      const next = { ...curr, ...updates };
      return next;
    });
    this.persistSettingsToServer(this.settings());
    this.showToast('Store & WhatsApp settings updated!');
  }

  async resetToDefaultData() {
    await clearAllHighResImages();
    this.products.set(INITIAL_PRODUCTS);
    this.settings.set(DEFAULT_SETTINGS);
    this.selectedSize.set('L');
    this.activeGalleryView.set('front');
    this.quantity.set(1);
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.removeItem(STORAGE_KEY_PRODUCTS);
      window.localStorage.removeItem(STORAGE_KEY_SETTINGS);
    }
    this.persistProductsToServer(INITIAL_PRODUCTS);
    this.persistSettingsToServer(DEFAULT_SETTINGS);
    this.showToast('Reset to original factory specs.');
  }

  // ==========================================
  // 9. ADMIN AUTHENTICATION METHODS
  // ==========================================
  async verifyAdminPin(pin: string): Promise<boolean> {
    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin }),
      });
      if (res.ok) {
        this.isAdminAuthenticated.set(true);
        this.adminAuthError.set(null);
        if (typeof window !== 'undefined' && window.sessionStorage) {
          window.sessionStorage.setItem(STORAGE_KEY_ADMIN_AUTH, 'true');
        }
        return true;
      }
    } catch {
      // Offline fallback: check default PIN
      if (pin === 'gods2026') {
        this.isAdminAuthenticated.set(true);
        this.adminAuthError.set(null);
        return true;
      }
    }
    this.adminAuthError.set('Incorrect admin access PIN. Please try again.');
    return false;
  }

  adminLogout() {
    this.isAdminAuthenticated.set(false);
    if (typeof window !== 'undefined' && window.sessionStorage) {
      window.sessionStorage.removeItem(STORAGE_KEY_ADMIN_AUTH);
    }
    this.isAdminOpen.set(false);
    this.showToast('Admin session logged out.');
  }

  // ==========================================
  // 10. CART & ORDER ACTIONS
  // ==========================================
  addToCart(product?: Product, size?: HoodieSize, qty?: number, view?: 'front' | 'back') {
    const targetProduct = product || this.activeProduct();
    const targetSize = size || this.selectedSize();
    const targetQty = qty || this.quantity();
    const targetView = view || 'front';

    const unitPrice = calculateItemPrice(targetProduct.basePrice, targetProduct.price3XL, targetSize);
    const cartItemId = `${targetProduct.id}-${targetSize}`;
    const displayImg = targetView === 'front' ? targetProduct.frontImage : targetProduct.backImage;

    this.cart.update((items) => {
      const existingIndex = items.findIndex((i) => i.id === cartItemId);
      if (existingIndex > -1) {
        const next = [...items];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: Math.min(10, next[existingIndex].quantity + targetQty),
        };
        return next;
      } else {
        return [
          ...items,
          {
            id: cartItemId,
            productId: targetProduct.id,
            productName: targetProduct.name,
            color: targetProduct.color,
            size: targetSize,
            unitPrice,
            quantity: targetQty,
            image: displayImg,
            viewUsed: targetView,
          },
        ];
      }
    });

    this.showToast(`Added ${targetProduct.name} (${targetSize}) to Bag!`);
  }

  buyNow(product?: Product, size?: HoodieSize, qty?: number, view?: 'front' | 'back') {
    this.addToCart(product, size, qty, view);
    this.isCheckoutOpen.set(true);
  }

  removeFromCart(itemId: string) {
    this.cart.update((items) => items.filter((i) => i.id !== itemId));
    this.showToast('Item removed from cart');
  }

  updateCartQuantity(itemId: string, qty: number) {
    if (qty <= 0) {
      this.removeFromCart(itemId);
      return;
    }
    this.cart.update((items) =>
      items.map((i) => (i.id === itemId ? { ...i, quantity: Math.min(10, qty) } : i))
    );
  }

  clearCart() {
    this.cart.set([]);
  }

  async submitOrder(customerDetails: OrderCustomerDetails): Promise<{ orderId: string; whatsAppUrl: string }> {
    const orderId = `GP-${Math.floor(10000 + Math.random() * 90000)}`;
    const items = [...this.cart()];
    const phone = this.settings().whatsappPhone;
    const countryCode = this.settings().countryCode;
    const fullNumber = countryCode + phone;

    // Log order server-side
    try {
      await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: orderId,
          items,
          totals: this.cartTotals(),
          customer: customerDetails,
        }),
      });
    } catch {
      // Continue client-side
    }

    const whatsAppUrl = generateWhatsAppOrderUrl(fullNumber, items, customerDetails, orderId);
    return { orderId, whatsAppUrl };
  }

  // ==========================================
  // 11. UI MODAL CONTROLLERS
  // ==========================================
  openCart() {
    this.isCartOpen.set(true);
  }
  closeCart() {
    this.isCartOpen.set(false);
  }

  openAdmin() {
    this.isAdminOpen.set(true);
  }
  closeAdmin() {
    this.isAdminOpen.set(false);
  }

  openSizeGuide() {
    this.isSizeGuideOpen.set(true);
  }
  closeSizeGuide() {
    this.isSizeGuideOpen.set(false);
  }

  openCheckout() {
    this.isCheckoutOpen.set(true);
  }
  closeCheckout() {
    this.isCheckoutOpen.set(false);
  }

  openZoom() {
    this.isZoomOpen.set(true);
  }
  closeZoom() {
    this.isZoomOpen.set(false);
  }

  openReturnModal() {
    this.isReturnModalOpen.set(true);
  }
  closeReturnModal() {
    this.isReturnModalOpen.set(false);
  }

  // Toast feedback
  showToast(msg: string) {
    this.toastMessage.set(msg);
    setTimeout(() => {
      if (this.toastMessage() === msg) {
        this.toastMessage.set(null);
      }
    }, 3200);
  }
}
